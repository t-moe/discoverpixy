

#include "../settings.h"
#include"../types.h"
#include "../OpSys/ptask.h"


#include "../tft/tft.h"

void sensInit()
{
	//Init G Sensor ////////////////////////////////////////////////////////////////////////////////////
		//SPI D1 Touch
		USARTC0.BAUDCTRLA = 255;
		USARTC0.BAUDCTRLB |= 0xF;
		USARTC0.CTRLB |= USART_RXEN_bm | USART_TXEN_bm;		//Receive Enable, Transmit Enable
		USARTC0.CTRLC |= USART_CMODE_MSPI_gc;				//Master SPI Mode
		//USARTC0.CTRLA = USART_RXCINTLVL_LO_gc;				//Interrupt Level0 Enabled

		USARTC0.CTRLC &= ~(0x02);		//UCPHA bit l�schen
		//PORTA.PIN1CTRL |= PORT_INVEN_bm;	//invert SCK
		
		
		PORTA.OUTSET = Sensor_SPI_CS_bm;			//Set CS
		
		/*
		PORTC.DIRSET = Sensor_SPI_SCK_bm | Sensor_SPI_DOUT_bm;	//SCK und TX
		PORTC.PIN2CTRL = PORT_OPC_PULLUP_gc;		//DIN
		PORTA.DIRSET = Sensor_SPI_CS_bm;
		PORTA.OUTSET = Sensor_SPI_CS_bm;			//Set CS

		PORTR.DIRSET = Sensor_Reset_bm;
		PORTR.OUTSET = Sensor_Reset_bm; //LOW ACTIV!!!!!
		*/
		
	//Sensor Interrupts
		//Sensor Connected
		PORTA.DIRCLR = Sensor_Connected_bm;
		PORTA.INT1MASK = Sensor_Connected_bm;
		PORTA.PIN3CTRL |= PORT_ISC_BOTHEDGES_gc;
		PORTA.INTCTRL |= PORT_INT1LVL_LO_gc;
		//Sensor Int
		PORTR.DIRCLR = Sensor_Interrupt_bm;
		PORTR.INT0MASK = Sensor_Interrupt_bm;
		PORTR.PIN1CTRL |= PORT_OPC_PULLUP_gc | PORT_ISC_FALLING_gc;
		//PORTR.INTCTRL = PORT_INT0LVL_LO_gc;
}



volatile unsigned char complete=0;
volatile signed int z=0;
volatile signed int y=0;
volatile signed int x=0;
volatile unsigned char state=0;
void sensStart(void)
{
	if ((PORTA.IN & Sensor_Connected_bm) == Sensor_Connected_bm)
	{
			
		Sensor_CLR_CS;
		
		
		
		USARTC0.DATA = 0x00 << 2; //REVID Register


		while(!complete);
		complete=0;
		
		
		tftPrintf_P(30,50,WHITE,BLACK,BigFont,PSTR("0x%02X"),USARTC0.DATA);
		
		Sensor_SET_CS;	
			
		/*Sensor_CLR_CS;
		USARTC0.DATA = 0x09<<2; 
	
		while(!complete);
		complete=0;
		z/=8;
		y/=8;
		x/=8;
		Sensor_SET_CS;
		tftPrintf_P(140,100,WHITE,BLACK,SmallFont,PSTR("0x%04X %+5d"),x, x);
		tftPrintf_P(140,120,WHITE,BLACK,SmallFont,PSTR("0x%04X %+5d"), y,y);
		tftPrintf_P(140,140,WHITE,BLACK,SmallFont,PSTR("0x%04X %+5d"), z,z);*/
	}

	

}

ISR (USARTC0_RXC_vect)	//SPI transmission Finish Interrupt
{
	x = USARTC0.DATA;
	complete=1;
	//SPIF=0;
/*
	switch(state)
	{
		case 0:
			USARTC0.DATA; // Read SPI Data (Necessary for AVR Platfrom)
			USARTC0.DATA=0x00;
			state++;
		break;
		case 1:
			z=USARTC0.DATA<<8;
			USARTC0.DATA=0x00;
			state++;
		break;
		case 2:
			z|=USARTC0.DATA;
			USARTC0.DATA=0x00;
			state++;
		break;
		case 3:
			y=USARTC0.DATA<<8;
			USARTC0.DATA=0x00;
			state++;
		break;
		case 4:
			y|=USARTC0.DATA;
			USARTC0.DATA=0x00;
			state++;
		break;
		case 5:
			x=USARTC0.DATA<<8;
			USARTC0.DATA=0x00;
			state++;
		break;
		case 6:
			x|=USARTC0.DATA;
			state=0;
			complete=1;
		break;

	}  */
}	  

//Sensor Connected
ISR (PORTA_INT1_vect)
{
	if ((PORTA.IN & Sensor_Connected_bm) == Sensor_Connected_bm)
	{
		PORTC.DIRSET = Sensor_SPI_SCK_bm | Sensor_SPI_DOUT_bm;	//SCK und TX
		PORTC.PIN2CTRL = PORT_OPC_PULLUP_gc;		//DIN
		PORTA.DIRSET = Sensor_SPI_CS_bm;
		PORTR.DIRSET = Sensor_Reset_bm;
		
		//Init Sensor
		PORTR.OUTCLR = Sensor_Reset_bm; //Force Reset
		PORTR.OUTSET = Sensor_Reset_bm;
		
		USARTC0.DATA;
		USARTC0.CTRLA = USART_RXCINTLVL_LO_gc;				//Interrupt Level0 Enabled
		/*Sensor_CLR_CS;
		
		_delay_ms(500);
		unsigned char d;
		do 
		{
			USARTC0.DATA = 0x02 << 2; //STATUS Register
			while((USARTC0.STATUS & USART_RXCIF_bm)==0);
			d= USARTC0.DATA;
		} while (d!=0x00);
		
		
		
		USARTC0.DATA = 0x09 << 2; //REVID Register
		while((USARTC0.STATUS & USART_RXCIF_bm)==0);
		d= USARTC0.DATA;
			
		tftPrintf_P(30,50,WHITE,BLACK,BigFont,PSTR("0x%02X"),d);*/
	/*	if(d==0) // Ok
		{
			tftPrintf_P(30,50,WHITE,BLACK,BigFont,PSTR("0x%02X"),d);
		}
		else{}//wrong sensor?*/
			

	}
	else
	{
		USARTC0.CTRLA = USART_RXCINTLVL_OFF_gc;
		
		PORTC.DIRCLR = Sensor_SPI_SCK_bm | Sensor_SPI_DOUT_bm;	//SCK und TX
		PORTC.PIN2CTRL = PORT_OPC_TOTEM_gc;		//DIN
		PORTA.DIRCLR = Sensor_SPI_CS_bm;
		//PORTA.OUTSET = Sensor_SPI_CS_bm;			//Set CS

		PORTR.DIRCLR = Sensor_Reset_bm;
		//PORTR.OUTSET = Sensor_Reset_bm; //LOW ACTIV!!!!!
	
	}

	
}

//Sensor Int
ISR (PORTR_INT0_vect)
{
	//Task adde welcher den Ringbuffer ausliest
	;
}

