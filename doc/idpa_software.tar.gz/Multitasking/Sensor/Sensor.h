extern void sensInit();
extern void sensStart(void);