#include "settings.h"
#include "types.h"
#include "Tft/tft.h"
#include "Rtc/rtc.h"
#include "AD/AD.h"
#include "OpSys/ptask.h"
#include "OpSys/timer.h"
#include "Statusbar.h"


static prog_uint16_t Statusbar_1px[0x20] PROGMEM ={
0x4A49, 0x4A49, 0x4A49, 0x4228, 0x4228, 0x4208, 0x4208, 0x39E7, 0x39E7, 0x39C7, 0x39C7, 0x31A6, 0x31A6, 0x3186, 0x2965, 0x2124,   // 0x0010 (16)
0x2104, 0x18E3, 0x18C3, 0x18C3, 0x10A2, 0x10A2, 0x1082, 0x0861, 0x0861, 0x0841, 0x0841, 0x0020, 0x0020, 0x0000, 0x0000, 0x0000,   // 0x0020 (32)
};


#define STATUSBAR_BASEPRIORITY 0


unsigned int U_Akku=0;
unsigned int U_Vin=0;	
	
PTASK_STRUCT* Sbar_Time_Task;
unsigned char Sbar_Time_Event;

PTASK_STRUCT* Sbar_Akku_Task;
unsigned char Sbar_Akku_Event;

TIMER_STRUCT* Sbar_Time_Timer;


//Callback from Timer, Will be Called from Timer ISR every xx seconds (configured in main)
void Sbar_Time_Timer_Run(void * timer)
{
	PTask_QueueEvent(Sbar_Time_Task,0); // Fire a Event with 0 Data
	PTask_QueueEvent(Sbar_Akku_Task,0); // Fire a Event with 0 Data
}

//Battlader Pins Interrupt
//Will be called when at least one of the three pins changed it's state.
ISR (PORTA_INT0_vect)
{
	PTask_QueueEvent(Sbar_Akku_Task,0); // Fire a Event with 0 Data
}

//Statusbar Time Task, Will be Run as long as Events are Available.
void Sbar_Time_Task_Run(void *task, UCHAR length)
{
	//Because we have no Data, we don't need to read the Event (happens automatically)
	unsigned long ticks;
	getTime(&ticks);
	ticks2struct(&ticks,&systime);
	tftDrawGradient(0,0,0+64,32,Statusbar_1px); //Redraw Background behind Time & Date
	//Draw Time & Date
	tftPrintf_P(0,3,WHITE,TRANSPARENT, SmallFont, PSTR("%02u:%02u"),systime.std,systime.min);		
	tftPrintf_P(0,15,WHITE,TRANSPARENT, SmallFont, PSTR("%02u.%02u.%02u"),systime.tag,systime.monat,systime.jahr);
	
}

static unsigned char icon = 100;
static unsigned char oldIcon=255;
static unsigned char iconmax= 0;
static unsigned char iconmin=0;
void Sbar_Akku_Task_Run(void *task, UCHAR length)
{
	//Because we have no Data, we don't need to read the Event (happens automatically)
	#define BATT_MAX_CHARGING 4200
	#define BATT_MAX_DISCHARGING 4160
	#define BATT_MIN_CHARGING 3450
	#define BATT_MIN_DISCHARGING 3400
	
	unsigned char battstat = (PORTA.IN & Batt_STATPINS_bm);
	Spannung(&U_Akku,&U_Vin);
		
	/*tftPrintf_P(70,2,WHITE,BLACK, SmallFont, PSTR("Akku: %4umV"),U_Akku);		
	tftPrintf_P(70,2+14,WHITE,BLACK, SmallFont,  PSTR("Uin: %4umV"),U_Vin);
*/
	switch(battstat)
	{
		
		case Batt_STATUS_SHUTDOWN:
			if(U_Akku < BATT_MIN_DISCHARGING) iconmin =0;
			else iconmin = (unsigned long)(U_Akku-BATT_MIN_DISCHARGING)*100/(BATT_MAX_DISCHARGING-BATT_MIN_DISCHARGING);
			if(iconmin>100) iconmin = 100;
			if(iconmin<icon) icon =iconmin;
			
		break;
		case Batt_STATUS_CHARGE:
			/*iconmax = (unsigned long)(U_Akku-BATT_MIN_CHARGING)*22/(BATT_MAX_CHARGING-BATT_MIN_CHARGING)+110;
			if(iconmax>132) iconmax = 132;
			icon++;
			if(icon <110) icon =110;
			if(icon>iconmax) icon = 110;*/
			iconmax = (unsigned long)(U_Akku-BATT_MIN_CHARGING)*22/(BATT_MAX_CHARGING-BATT_MIN_CHARGING)+110;
			if(iconmax>132) iconmax = 132;
			if(iconmax>icon) icon =iconmax;
		break;
		case Batt_STATUS_STANDBY:
		case Batt_STATUS_CHARGEC:
			icon=133; //Full charged
		break;
		default:
			icon=0;
			tftPrint(30,220,GREEN,BLACK, BigFont,"Default case?");
			tftPrint(30,200,(battstat & Batt_STAT2_bm)?GREEN:RED,BLACK, BigFont,"B_STAT2");
			tftPrint(30,180,(battstat & Batt_STAT1_bm)?GREEN:RED,BLACK, BigFont,"B_STAT1");
			tftPrint(30,160,(battstat & Batt_STATPG_bm)?GREEN:RED,BLACK, BigFont,"B_STATGP");
			break;
	}
	if(icon!=oldIcon)
	{
		tftDrawIconUnscaledStreamedRaw(WIDTH-32,0,32,icon,"BST1.raw");
		oldIcon=icon;
	}
		
	
	if (U_Akku < BATT_MIN_DISCHARGING)
	{
		PORTC.DIRCLR = Batt_ON_bm;		//Power ausschalten
		tftClear(RED);
		cli(); //Disable all Interrupts
		while(1); //Stirb :)
	}
	else
		PORTC.DIRSET = Batt_ON_bm;
}



void Statusbar_Init()
{
	
	PORTA.DIRCLR = Batt_STAT1_bm | Batt_STAT2_bm | Batt_STATPG_bm;		//Set as Input
	PORTA.PIN4CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_BOTHEDGES_gc;		//activate Pullup
	PORTA.PIN5CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_BOTHEDGES_gc;		//and trigger Interrupt0 on Both Edges
	PORTA.PIN6CTRL = PORT_OPC_PULLUP_gc | PORT_ISC_BOTHEDGES_gc;
	PORTA.INT0MASK = Batt_STAT1_bm | Batt_STAT2_bm | Batt_STATPG_bm;	//Interrupt0 Triggers on all 3 Pins
	
	
	Sbar_Time_Timer= Timer_Add(20000,0,Sbar_Time_Timer_Run);
	Timer_Start(Sbar_Time_Timer);
	
	Sbar_Time_Task = PTask_AddTask(Sbar_Time_Task_Run,STATUSBAR_BASEPRIORITY,1,&Sbar_Time_Event);
	Sbar_Akku_Task = PTask_AddTask(Sbar_Akku_Task_Run,STATUSBAR_BASEPRIORITY+1,1,&Sbar_Akku_Event);


	Statusbar_Redraw();
	PORTA.INTCTRL |= PORT_INT0LVL_LO_gc;			//Interrupt0 Level is LOW = 0

}

void Time_Redraw()
{
	PTask_QueueEvent(Sbar_Time_Task,0); // Fire a Event with 0 Data
}
void Statusbar_Redraw()
{
	tftDrawGradient(0,0,400,32,Statusbar_1px);
	oldIcon=255;
	PTask_Run_Now(Sbar_Akku_Task);
	PTask_Run_Now(Sbar_Time_Task);
}

void Statusbar_SetTitle(char* txt)
{
	unsigned char w = tftPrintCalcWidth(SmallFont,txt);
	tftDrawGradient(HWIDTH-10*8,0,8*20,32,Statusbar_1px);
	tftPrintf_P(HWIDTH-w/2,(32-12)/2,WHITE,TRANSPARENT,SmallFont,PSTR("%-20s"),txt);
	tftDrawLine(HWIDTH-w/2-6,32-9,HWIDTH+w/2+4,32-9,WHITE);
	
}