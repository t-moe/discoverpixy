extern void Log(char* str);
extern void Log_Show();
extern void Log_Hide();
extern void Log_Init();