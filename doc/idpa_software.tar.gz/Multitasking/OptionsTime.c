#include "settings.h"
#include "types.h"
#include "tft/tft.h"
#include "Rtc/rtc.h"
#include "touch/touch.h"
#include "Gui/button.h"
#include "Gui/checkbox.h"
#include "Gui/softinput.h"
#include "Alarm.h"
#include "Statusbar.h"
#include "Mainmenu.h"
#include "Options.h"
#include <ctype.h> //for softinput
#include <string.h>
#include <stdlib.h>

#define C_TEXT_HIGHLIGHTED HEX(0xF2F4F5)

static BUTTON_STRUCT*  b_buttons;
static TOUCH_AREA_STRUCT* ta_touchareas;


static unsigned char hour;
static unsigned char min;
static unsigned int year;
static unsigned char month;
static unsigned char day;

static enum {K_NONE,K_TIME_HOUR,K_TIME_MINUTE,K_DAY,K_MONTH,K_YEAR}activeKeyboard;


static void soft_cb(char** b, unsigned char ind_nospace,unsigned char ind_spaced)
{
	
	switch(activeKeyboard)
	{
		case K_TIME_HOUR:
			if(hour>=10) hour%=10;
			hour*=10;
			hour+=b[ind_spaced][0] -48; //48 = Asci '0'
			tftPrintf_P(10 + 6 * 16 + 10 + 8,82 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%02u"),hour);
			break;
		case K_TIME_MINUTE:
			if(min>=10) min%=10;
			min*=10;
			min+=b[ind_spaced][0]-48; //48 = Asci '0'
			tftPrintf_P(10 + 6 * 16 + 10 + 8 + 3 * 16,82 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%02u"),min);
		break;
		case K_YEAR:
			if(year>=1000) year%=1000;
			year*=10;
			year+=b[ind_spaced][0]-48; //48 = Asci '0'
			tftPrintf_P(10 + 6 * 16 + 10 + 8 + 8 * 16,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%4u"),year);
		break;
		case K_MONTH:
			month=ind_nospace+1;
			tftPrintf_P(10 + 6 * 16 + 10 + 8 + 4 * 16,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%s"),allmonth[ind_spaced]);
		break;
		case K_DAY:
			if(day>=10) day%=10;
			day*=10;
			day+=b[ind_spaced][0]-48; //48 = Asci '0'
			tftPrintf_P(10 + 6 * 16 + 10 + 8 ,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%2u"),day);
		break;
		default:break;
	

	}	

}

static void ta_fullspace_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard!=K_NONE)
	{
		if(activeKeyboard==K_TIME_HOUR || activeKeyboard == K_TIME_MINUTE)
		{
			if(hour>23) hour=23;
			if(min>59) min = 59;
			tftPrintf_P(10 + 6 * 16 + 10 + 8,82 + 8,BLACK,WHITE,BigFont,PSTR("%02u:%02u"),hour,min);
		}
		else
		{
			if(year>2099) year = 2099;
			if(year<2000) year = 2000;
			/*if(month>12) month=12;
			if(month<1) month =1;*/
			unsigned char dom = getDaysOfMonth(month,year);
			if(day>dom) day = dom;
			if(day<1) day = 1;
			unsigned char m_ind = month;
			if(month<=6) m_ind--;
			tftPrintf_P(10 + 6 * 16 + 10 + 8,42+ 8,BLACK,WHITE,BigFont,PSTR("%2u. %s %4u"),day,allmonth[m_ind],year);
			
		}
		
		activeKeyboard = K_NONE;
		guiRemoveSoftInput();
		tftFillRectangle(0,DHEIGHT-80,DWIDTH,DHEIGHT,HEX(0x65EAFF));	
		
		guiAddButton(&b_buttons[0]); // b_alarm_ok
		guiAddButton(&b_buttons[1]); // b_alarm_cancel	
		guiRedrawButton(&b_buttons[0]);
		guiRedrawButton(&b_buttons[1]);
	}

}

static void ta_hour_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		hour=0;
		tftPrint_P(10 + 6 * 16 + 10 + 8,82 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("  "));
		guiRemoveButton(&b_buttons[0]); // b_alarm_ok
		guiRemoveButton(&b_buttons[1]); // b_alarm_cancel	
		activeKeyboard = K_TIME_HOUR;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}
static void ta_min_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		min=0;
		tftPrint_P(10 + 6 * 16 + 10 + 8 + 3 * 16,82 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("  "));
		guiRemoveButton(&b_buttons[0]); // b_alarm_ok
		guiRemoveButton(&b_buttons[1]); // b_alarm_cancel	
		activeKeyboard = K_TIME_MINUTE;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}

static void ta_day_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		day=0;
		tftPrint_P(10 + 6 * 16 + 10 + 8 ,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("  "));
		guiRemoveButton(&b_buttons[0]); // b_alarm_ok
		guiRemoveButton(&b_buttons[1]); // b_alarm_cancel	
		activeKeyboard = K_DAY;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}

static void ta_month_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		month=0;
		tftPrint_P(10 + 6 * 16 + 10 + 8 + 4 * 16,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("   "));
		guiRemoveButton(&b_buttons[0]); // b_alarm_ok
		guiRemoveButton(&b_buttons[1]); // b_alarm_cancel	
		activeKeyboard = K_MONTH;
		ta_touchareas[0].y2=DHEIGHT-80;//ta_fullspace
		guiAddSoftInput(allmonth,80,soft_cb);
	}
}
static void ta_year_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		year=0;
		tftPrint_P(10 + 6 * 16 + 10 + 8 + 8 * 16,42 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("    "));
		guiRemoveButton(&b_buttons[0]); // b_alarm_ok
		guiRemoveButton(&b_buttons[1]); // b_alarm_cancel	
		activeKeyboard = K_YEAR;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}

static void b_alarm_cancel_cb(void* button)
{

	for(unsigned char i=0; i<2; i++)
		guiRemoveButton(&b_buttons[i]);
	for(unsigned char i=0; i<6; i++)	
		touchUnregisterArea(&ta_touchareas[i]);
	free(ta_touchareas);
	free(b_buttons);

	Options_Show();
}

static void b_alarm_ok_cb(void* button)
{
	systime.jahr = year -2000;
	systime.monat = month;
	systime.tag = day;
	systime.std =hour;
	systime.min = min;
	systime.sec = 0;
	systime.szeit = isSommerzeit(&systime);
	Wochentag(&systime);
	unsigned long ticks;
	struct2ticks(&systime,&ticks);
	setTime(&ticks);
	Time_Redraw();
	b_alarm_cancel_cb(&b_buttons[1]);
}


void uiOptionsTimeShow()
{
	activeKeyboard = K_NONE;
	hour=systime.std;
	min=systime.min;
	year = 2000+ systime.jahr;
	month = systime.monat;
	day = systime.tag;
	
	
	//Reserve Dynamic Memory
	ta_touchareas = malloc(sizeof(TOUCH_AREA_STRUCT)*6);
	b_buttons = malloc(sizeof(BUTTON_STRUCT)*2);

	
	
	Statusbar_SetTitle("Zeit einstellen");
	tftFillRectangle(0,32,DWIDTH,DHEIGHT,HEX(0x65EAFF)); //draw BG

	//Touch Area for FullSpace without Statusbar and Softinput
	ta_touchareas[0].x1=0; //Start X of Area
	ta_touchareas[0].y1=32; //Start Y of Area
	ta_touchareas[0].x2=DWIDTH; //End X of Area
	ta_touchareas[0].y2=32; //End Y of Area -> Will be changed before softinput opens
	ta_touchareas[0].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[0].callback =ta_fullspace_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[0]); //Register Area (and run the callback from now on)
	
	

	unsigned char y = 42;

	//Alarm Name

	tftPrint_P(10,y + 7 ,BLACK,TRANSPARENT,BigFont,PSTR("Datum:"));
	tftFillRectangle(10 + 6 * 16 + 10,y,DWIDTH-8,y +31,WHITE);
	tftDrawRectangle(10 + 6 * 16 + 10,y,DWIDTH-8,y+ 31,BLACK);
	unsigned char m_ind = month;
	if(month<=6) m_ind--;
	tftPrintf_P(10 + 6 * 16 + 10 + 8,y + 8,BLACK,WHITE,BigFont,PSTR("%2u. %s %4u"),day,allmonth[m_ind],year);
	
	//ta_day
	ta_touchareas[1].x1=10 +6 * 16 + 10; //Start X of Area
	ta_touchareas[1].y1=y; //Start Y of Area
	ta_touchareas[1].x2=ta_touchareas[1].x1+47; //End X of Area
	ta_touchareas[1].y2=ta_touchareas[1].y1 +31; //End Y of Area
	ta_touchareas[1].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[1].callback =ta_day_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[1]); 
	
	//ta_month
	ta_touchareas[2].x1=ta_touchareas[1].x2+16; //Start X of Area
	ta_touchareas[2].y1=y; //Start Y of Area
	ta_touchareas[2].x2=ta_touchareas[2].x1+47; //End X of Area
	ta_touchareas[2].y2=ta_touchareas[2].y1 +31; //End Y of Area
	ta_touchareas[2].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[2].callback =ta_month_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[2]); 
	
	//ta_year
	ta_touchareas[3].x1=ta_touchareas[2].x2+16; //Start X of Area
	ta_touchareas[3].y1=y; //Start Y of Area
	ta_touchareas[3].x2=ta_touchareas[3].x1+63; //End X of Area
	ta_touchareas[3].y2=ta_touchareas[3].y1 +31; //End Y of Area
	ta_touchareas[3].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[3].callback =ta_year_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[3]);


	y+=32+8;
	tftPrint_P(10,y +7 ,BLACK,TRANSPARENT,BigFont,PSTR("Zeit:"));
	tftFillRectangle(10 + 6 * 16 + 10,y,DWIDTH-8,y +31,WHITE);
	tftDrawRectangle(10 +6 * 16 + 10,y,DWIDTH-8,y+ 31,BLACK);
	tftPrintf_P(10 + 6 * 16 + 10 + 8,y + 8,BLACK,WHITE,BigFont,PSTR("%02u:%02u"),hour,min);
	
	//ta_hour
	ta_touchareas[4].x1=10 +6 * 16 + 10; //Start X of Area
	ta_touchareas[4].y1=y; //Start Y of Area
	ta_touchareas[4].x2=ta_touchareas[4].x1+40; //End X of Area
	ta_touchareas[4].y2=ta_touchareas[4].y1 +31; //End Y of Area
	ta_touchareas[4].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[4].callback =ta_hour_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[4]); 
	
	//ta_min
	ta_touchareas[5].x1=ta_touchareas[4].x2+1; //Start X of Area
	ta_touchareas[5].y1=y; //Start Y of Area
	ta_touchareas[5].x2=ta_touchareas[5].x1+40; //End X of Area
	ta_touchareas[5].y2=ta_touchareas[5].y1 +31; //End Y of Area
	ta_touchareas[5].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[5].callback =ta_min_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[5]); 
	
	
	
		
	//b_alarm_ok	
	b_buttons[0].base.x1=25; //Start X of Button
	b_buttons[0].base.y1=DHEIGHT - 30; //Start Y of Button
	b_buttons[0].base.x2=b_buttons[0].base.x1+160; //Auto Calculate X2 with String Width
	b_buttons[0].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[0].txtcolor=WHITE; //Set foreground color
	b_buttons[0].bgcolor=HEX(0x54FF45); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[0].font=BigFont; //Select Font
	b_buttons[0].text="Ok"; //Set Text (For formatted strings take sprintf)
	b_buttons[0].callback=b_alarm_ok_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[0]); //Register Button (and run the callback from now on)
	
	//b_alarm_cancel
	b_buttons[1].base.x1=210; //Start X of Button
	b_buttons[1].base.y1=DHEIGHT - 30; //Start Y of Button
	b_buttons[1].base.x2=b_buttons[1].base.x1+160; //Auto Calculate X2 with String Width
	b_buttons[1].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[1].txtcolor=WHITE; //Set foreground color
	b_buttons[1].bgcolor=HEX(0xC2C2C2); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[1].font=BigFont; //Select Font
	b_buttons[1].text="Abbrechen"; //Set Text (For formatted strings take sprintf)
	b_buttons[1].callback=b_alarm_cancel_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[1]); //Register Button (and run the callback from now on)
}

