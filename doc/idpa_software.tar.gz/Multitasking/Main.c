/*
 * Multitasking.c
 *
 * Created: 24.12.2011 10:38:30
 *  Author: Dreamcooled
 */ 
#include "settings.h"
#include "types.h"
#include "Device/device.h"
#include "Tft/tft.h"
#include "Touch/touch.h"
#include "Rtc/rtc.h"
#include "SD/pff.h"
#include "AD/AD.h"
#include "PWM/PWM.h"
#include "OpSys/ptask.h"
#include "OpSys/timer.h"
#include "Gui/button.h"
#include "Gui/checkbox.h"
#include "Gui/softinput.h"
#include "Statusbar.h"
#include "Mainmenu.h"
#include <stdlib.h>

FATFS fs;
static void start()
{
	USARTD0.BAUDCTRLA = 0x03;		//Baud Rate erh�hen
	USARTD0.BAUDCTRLB = 0x00;
	Statusbar_Init();
	tftDrawLinearGradient(0, 32,WIDTH, HEIGHT-32,  HEX(0x65EAFF),HEX(0x6C65FF),TOP_BOTTOM);
	Mainmenu_Show();
	Set_Backlight(200);
}	
	
static void b_rectry_cb(void* button)
{
	
	if(pf_mount(&fs)==FR_OK)
	{
		BUTTON_STRUCT * b = (BUTTON_STRUCT*) button;
		guiRemoveButton(b);
		free(b);
		start();
	}
	else pf_mount(NULL);
}
int main(int argc, char* argv[])
{
	//Hardware Init
	Device_Init();
	PTask_Init();
	Timer_Init();
	RTC_Init();
	AD_Init();
	PWM_Init();
	
	
	touchInit();
	tftInit();
	//sensInit();
	
	if(pf_mount(&fs)!=FR_OK)
	{
		pf_mount(NULL);
		BUTTON_STRUCT * b = malloc(sizeof(BUTTON_STRUCT));
		b->base.x1 = 120;
		b->base.y1 = 210;
		b->base.x2=AUTO;
		b->base.y2=AUTO;
		b->bgcolor=RED;
		b->font= BigFont;
		b->text="Erneut versuchen";
		b->txtcolor = WHITE;
		b->callback = b_rectry_cb;
		guiAddButton(b);
		
		tftPrint_P(10,10,WHITE,BLACK,BigFont,PSTR("SD Karte nicht erkannt!"));
		tftPrint_P(10,10+16,WHITE,BLACK,BigFont,PSTR("Korrekt eingelegt?"));
		Set_Backlight(200);
	}
	else start();

	while(1) PTask_Loop();	 // Run Cooperative Multitasking
	return 0;
}




ISR(BADISR_vect) //Catchall interrupt
{
	Set_LED(255);
}