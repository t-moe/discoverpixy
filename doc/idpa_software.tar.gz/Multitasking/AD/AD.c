/*
 * AD.c
 *
 * Created: 03.01.2012 10:24:46
 *  Author: Excalibur
 */ 

#include "../settings.h"
#include "AD.h"

void AD_Init (void)
{
	//AD Wandler////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		PORTA.DIRCLR = MP_Batt_bm | MP_Vin_bm;
		//AD Configuration
		ADCA.CTRLB = ADC_RESOLUTION_12BIT_gc ;		//12Bit ADC Modus, unsigned mode
		ADCA.REFCTRL |= ADC_REFSEL_INT1V_gc;		//Vref is internal 1V
		ADCA.PRESCALER |= ADC_PRESCALER_DIV512_gc;	//division factor for the conversion clock	//bimene h�here clock wirds ungnau
		ADCA.CTRLA |= ADC_ENABLE_bm;				//Enable ADC
		//Channel 1
		ADCA.CH1.CTRL |= ADC_CH_INPUTMODE_SINGLEENDED_gc;	//single ended Mode 01
		ADCA.CH1.MUXCTRL |= ADC_CH_MUXPOS_PIN1_gc;			//set Pin 1 as Input
		//Channel 2
		ADCA.CH2.CTRL |= ADC_CH_INPUTMODE_SINGLEENDED_gc;	//single ended Mode 01
		ADCA.CH2.MUXCTRL |= ADC_CH_MUXPOS_PIN0_gc;			//set Pin 0 as Input
		/*
		ADCA.REFCTRL |= ADC_TEMPREF_bm;					//Tempsensor on
		ADCA.CH2.CTRL |= ADC_CH_INPUTMODE_INTERNAL_gc;	//single ended Mode 00
		ADCA.CH2.MUXCTRL = 0;							//Positive Input is Tempsensor
		*/
}

void Spannung (unsigned int* U_Akku, unsigned int* U_Eingang)
{
	unsigned long Messwerte_CH1=0;
	unsigned long Messwerte_CH2=0;
	unsigned char Messungen;
	 
	for (Messungen = 0; Messungen < ANZAHL_MESSUNGEN; Messungen++)
	{
		 ADCA.CH1.CTRL |= ADC_CH_START_bm;			//start Messung
		 ADCA.CH2.CTRL |= ADC_CH_START_bm;			//start Messung
		 while (!(ADCA.CH1.INTFLAGS & 0x01));		//warten bis Messung fertig
		 ADCA.CH1.INTFLAGS = 0x01;					//Clear Interrupt flag
		 Messwerte_CH1 += ADCA.CH1.RES;
		 while (!(ADCA.CH2.INTFLAGS & 0x01));		//warten bis Messung fertig
		 ADCA.CH2.INTFLAGS = 0x01;					//Clear Interrupt flag
		 Messwerte_CH2 += ADCA.CH2.RES;
	}	 
	//			(			Spannung am Messpunkt					)*	Verh�ltnis	
	*U_Akku = (Messwerte_CH1*VREF/4095/ANZAHL_MESSUNGEN-AD_OFFSET_CH1)*AD_RATIO_CH1/10;
	*U_Eingang =  (Messwerte_CH2*VREF/4095/ANZAHL_MESSUNGEN-AD_OFFSET_CH2)*AD_RATIO_CH2/10;
}

unsigned int Akku_U (void)
{
	
	unsigned long Messwerte=0;
	unsigned char Messungen;
	 
	for (Messungen = 0; Messungen < ANZAHL_MESSUNGEN; Messungen++)
	{
		 ADCA.CH1.CTRL |= ADC_CH_START_bm;			//start Messung
		 while (!(ADCA.CH1.INTFLAGS & 0x01));		//warten bis Messung fertig
		 ADCA.CH1.INTFLAGS = 0x01;					//Clear Interrupt flag
		 Messwerte += ADCA.CH1.RES;
	}	 
	return (Messwerte*VREF/4095/ANZAHL_MESSUNGEN-AD_OFFSET_CH1)*AD_RATIO_CH1/10;
}
 
unsigned int Uin_U (void)
{
	unsigned long Messwerte=0;
	unsigned char Messungen;
	 
	for (Messungen = 0; Messungen < ANZAHL_MESSUNGEN; Messungen++)
	{
		 ADCA.CH2.CTRL |= ADC_CH_START_bm;			//start Messung
		 while (!(ADCA.CH2.INTFLAGS & 0x01));		//warten bis Messung fertig
		 ADCA.CH2.INTFLAGS = 0x01;					//Clear Interrupt flag
		 Messwerte += ADCA.CH2.RES;
	}	 
	return (Messwerte*VREF/4095/ANZAHL_MESSUNGEN-AD_OFFSET_CH2)*AD_RATIO_CH2/10;
}