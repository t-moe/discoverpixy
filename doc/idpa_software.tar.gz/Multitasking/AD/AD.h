/*
 * CProgram2.c
 *
 * Created: 03.01.2012 10:24:46
 *  Author: Excalibur
 */ 

#define AD_OFFSET_CH1	82		//Akku
#define AD_OFFSET_CH2	95		//Eingangspannung
#define AD_RATIO_CH1	54		//Verh�ltnis von Spannung Akku Real zu Spannung Messpunkt
#define AD_RATIO_CH2	62		//Verh�ltnis von Spannung Eingang Real zu Spannung Messpunkt
#define VREF		1000
#define ANZAHL_MESSUNGEN	10


extern void AD_Init (void);
extern void Spannung (unsigned int* U_Akku, unsigned int* U_Eingang);
extern unsigned int Akku_U (void); 
extern unsigned int Uin_U (void);
