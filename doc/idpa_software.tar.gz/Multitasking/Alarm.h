
typedef enum{
ALARM_ENABLE = 0x80,
ALARM_SO = 0x40,
ALARM_SA = 0x20,
ALARM_FR = 0x10,
ALARM_DO = 0x08,
ALARM_MI = 0x04,
ALARM_DI = 0x02,
ALARM_MO = 0x01
} ALARM_FLAGS;

#define ALARM_NAME_MAXLENGTH 17
typedef struct {
	char name[ALARM_NAME_MAXLENGTH+1]; 
	ALARM_FLAGS flags; //0x80 == Enabled, 0x01 = Montag ... 0x40 = Sonntag
	unsigned char hour;
	unsigned char min;
} ALARM_STRUCT;

extern void uiAlarmShow(ALARM_STRUCT* alarm);
extern void uiAlarmShowAll(void);

