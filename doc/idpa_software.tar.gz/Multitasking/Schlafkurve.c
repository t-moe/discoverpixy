#include "settings.h"
#include "types.h"
#include "Tft/tft.h"
#include "Touch/touch.h"
#include "Gui/button.h"
#include "Statusbar.h"
#include "Mainmenu.h"

#include <stdlib.h>
BUTTON_STRUCT* b_mainmenu;


static void b_mainmenu_cb(void* button)
{
	guiRemoveButton(b_mainmenu);
	free(b_mainmenu);
	Mainmenu_Show();
}



void uiGraphShow()
{
	Statusbar_SetTitle("Schlafkurve");
	b_mainmenu = malloc(sizeof(BUTTON_STRUCT));
	tftDrawBitmapUnscaledStreamedRaw(0,32,400,208,"info.raw");
	b_mainmenu->base.x1=400-170; //Start X of Button
	b_mainmenu->base.y1=DHEIGHT - 30; //Start Y of Button
	b_mainmenu->base.x2=b_mainmenu->base.x1+160; //Auto Calculate X2 with String Width
	b_mainmenu->base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_mainmenu->txtcolor=WHITE; //Set foreground color
	b_mainmenu->bgcolor=HEX(0x54FF45); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_mainmenu->font=BigFont; //Select Font
	b_mainmenu->text="Hauptmen�"; //Set Text (For formatted strings take sprintf)
	b_mainmenu->callback=b_mainmenu_cb; //Call b1_cb as Callback
	guiAddButton(b_mainmenu); //Register Button (and run the callback from now on)
}

