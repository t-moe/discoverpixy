/*
 * Options.c
 *
 * Created: 28.01.2012 20:25:45
 *  Author: Excalibur
 */ 
#include "settings.h"
#include "types.h"
#include "avr/eeprom.h"
#include "Tft/tft.h"
#include "PWM/PWM.h"
#include "Touch/touch.h"
#include "Gui/checkbox.h"
#include "Gui/button.h"
#include "Statusbar.h"
#include "Mainmenu.h"
#include "Options.h"
#include "OptionsTime.h"
#include <stdlib.h>

static BUTTON_STRUCT* b_buttons;
static TOUCH_AREA_STRUCT* t_areas;

static void b_mainmenu_cb(void* button)
{
	Options_Hide();
	Mainmenu_Show();
}


static void b_timedate_cb(void* button)
{
	Options_Hide();
	uiOptionsTimeShow();
}

static void b_poweroff_cb(void* button)
{
	Options_Hide();
	PORTC.DIRCLR = Batt_ON_bm;		//Power ausschalten
	cli(); //Disable all Interrupts
	while(1); //Stirb :)
}
static void t_brighness_cb (void* touchArea, TOUCH_ACTION triggeredAction)
{
	//TOUCH_AREA_STRUCT* area = (TOUCH_AREA_STRUCT*)touchArea;
	switch(triggeredAction)
	{
		/*case PEN_DOWN:
			area->hookedActions=PEN_MOVE | PEN_LEAVE | PEN_UP;
			break;
		case PEN_UP:
		case PEN_LEAVE:
			area->hookedActions=PEN_DOWN;
			break;*/
		case PEN_MOVE:
			//tftDrawPixel(touchX,touchY,WHITE);
			Set_Backlight(touchX-25);
		break;
		default:break;
	}	
	
	
}
void Options_Show(void)
{
	Statusbar_SetTitle("Optionen");
	tftDrawLinearGradient(0, 32,WIDTH, HEIGHT-32,  HEX(0x65EAFF),HEX(0x6C65FF),TOP_BOTTOM);
	b_buttons = malloc(sizeof(BUTTON_STRUCT)*3);
	t_areas = malloc(sizeof(TOUCH_AREA_STRUCT)*1);
	
	b_buttons[0].base.x1=25; //Start X of Button
	b_buttons[0].base.y1=42; //Start Y of Button
	b_buttons[0].base.x2=AUTO; //Auto Calculate X2 with String Width
	b_buttons[0].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[0].txtcolor=WHITE; //Set foreground color
	b_buttons[0].bgcolor=RGB(30,30,200); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[0].font=BigFont; //Select Font
	b_buttons[0].text="Zeit & Datum"; //Set Text (For formatted strings take sprintf)
	b_buttons[0].callback=b_timedate_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[0]); //Register Button (and run the callback from now on)
	
	
	b_buttons[1].base.x1=25; //Start X of Button
	b_buttons[1].base.y1=DHEIGHT - 30; //Start Y of Button
	b_buttons[1].base.x2=b_buttons[1].base.x1+160; //Auto Calculate X2 with String Width
	b_buttons[1].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[1].txtcolor=WHITE; //Set foreground color
	b_buttons[1].bgcolor=HEX(0x54FF45); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[1].font=BigFont; //Select Font
	b_buttons[1].text="Hauptmen�"; //Set Text (For formatted strings take sprintf)
	b_buttons[1].callback=b_mainmenu_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[1]); //Register Button (and run the callback from now on)
	
	b_buttons[2].base.x1=25; //Start X of Button
	b_buttons[2].base.y1=150; //Start Y of Button
	b_buttons[2].base.x2=AUTO; //Auto Calculate X2 with String Width
	b_buttons[2].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[2].txtcolor=WHITE; //Set foreground color
	b_buttons[2].bgcolor=RED; //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[2].font=BigFont; //Select Font
	b_buttons[2].text="Ganz Ausschalten"; //Set Text (For formatted strings take sprintf)
	b_buttons[2].callback=b_poweroff_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[2]); //Register Button (and run the callback from now on)
	
	tftPrint_P(25,80,WHITE,TRANSPARENT,BigFont,PSTR("Display Helligkeit:"));
	tftDrawLinearGradient(26,101,255,30,BLACK,WHITE,LEFT_RIGHT);
	tftDrawRectangle(25,100,25+255+1,100+30+1,RGB(240,0,240));
	t_areas[0].x1=26;
	t_areas[0].y1=101;
	t_areas[0].x2=26+254;
	t_areas[0].y2=100+29;
	t_areas[0].hookedActions =PEN_MOVE;// PEN_DOWN;
	t_areas[0].callback = t_brighness_cb;
	touchRegisterArea(&t_areas[0]);
	
	//opt_checkbox = malloc(sizeof(CHECKBOX_STRUCT)*1);
	
	//Zeit
		//Zeit
		//Datum
	//Display
		//Helligkeit
		//
	//Akku
		//Icon
		//Fastcharge
			/*opt_checkbox->base.x1 = 100; //x1
			opt_checkbox->base.y1 = 80; //y1
			opt_checkbox->base.x2 = 100 + 16; //x2
			opt_checkbox->base.y2 = 0; // y2 = 0. Api will calculate the difference (x2-x1 and y2-y1) and take the bigger difference as size. then y2 and x2 are recalculated with the new size.
			//The api will also add 1 px to the size if necessary to make the check-sign good looking.
			opt_checkbox->fgcolor = CHECKBOX_WIN_FG_COLOR;
			opt_checkbox->checked = FALSE; // Set wheater the Checkbox should be checked or unchecked after init.
			opt_checkbox->callback = c1_cb;
			guiAddCheckbox(&opt_checkbox);*/
	
	//Wecker
		//Weckton
	
}

void Options_Hide(void)
{
	for(unsigned char i=0; i<3; i++)
		guiRemoveButton(&b_buttons[i]);
	touchUnregisterArea(&t_areas[0]);
	free(t_areas);
	free(b_buttons);
}