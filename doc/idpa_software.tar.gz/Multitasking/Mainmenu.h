extern void Mainmenu_Show(void);
extern void Mainmenu_Hide(void);