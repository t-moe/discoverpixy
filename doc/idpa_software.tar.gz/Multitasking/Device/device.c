#include "../settings.h"
/***************************Timer*********************************
TCC0 PWm
TCC1 PWM
TCD0 Rtc
TCD1 Touch
TCE0 Frequenz
TCE1 frei
TCF0 OpSys Timer


*****************************************************************/
#include "../Tft/tft.h"
#include <avr/sleep.h> //for sleep


void Device_Init(void)
{	
	PORTC.DIRSET = 0x20;			//BATT_ON/OFF
	PORTC.OUTSET = 0x20;
	//SYSCLOCK/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//PLL Sysclock
	/*	1. Clock Source aktivieren
		2. Multiplikator setzen
		3. auf stabile Clock Source warten
		4. PLL einschalten
										*/
	#if(F_CPU > 32000000UL)
	
		while(!(OSC.STATUS & OSC_RC2MRDY_bm));	//Wenn Oscillator stabil wird das Flag RC2MRDY gesetzt und 2Mhz k�nnen benutzt werden
		OSC.PLLCTRL |= OSC_PLLSRC_RC2M_gc;		//2Mhz als PLL Clock Source
		OSC.PLLCTRL |= (F_CPU/1000000UL)/2;		//Multiplikator setzen
		OSC.CTRL |= OSC_PLLEN_bm;				//PLL einschalten
		
		//Sysclock auf PLL
		while(!(OSC.STATUS & OSC_PLLRDY_bm));	//Wenn Oscillator stabil wird das Flag PLLRDY gesetzt und 32Mhz k�nnen benutzt werden
		CCP = CCP_IOREG_gc;						//I/O Protection schutz aufheben f�r 4Cycles
		CLK.CTRL = CLK_SCLKSEL_PLL_gc;			//SysClock auf PLL einstellen
		OSC.CTRL = OSC_RC2MEN_bm | OSC_PLLEN_bm;//Alle Oszillatoren bis auf 2Mhz und PLL ausschalten
	#else
		//Sysclock auf 32MHz
		OSC.CTRL |= OSC_RC32MEN_bm;				//32MHz Oscillator einschalten BIT1 = OSC_RC32MEN wird gesetzt 
		while(!(OSC.STATUS & OSC_RC32MRDY_bm))	//Wenn Oscillator stabil wird das Flag RC32MRDY gesetzt und 32Mhz k�nnen benutzt werden
		{;}
		CCP = CCP_IOREG_gc;						//I/O Protection schutz aufheben f�r 4Cycles
		CLK.CTRL = CLK_SCLKSEL_RC32M_gc;		//Clock auf 32Mhz einstellen
		OSC.CTRL |= OSC_RC32MEN_bm;				//Alle Oszillatoren bis auf 2Mhz und PLL ausschalten
	#endif
	
		//Disable unnecessary Peripheral
		PR.PRGEN = PR_AES_bm | PR_EBI_bm | PR_DMA_bm;
		PR.PRPA = PR_DAC_bm | PR_AC_bm;
		PR.PRPB = PR_DAC_bm | PR_ADC_bm | PR_AC_bm;
		PR.PRPC = PR_TWI_bm | PR_SPI_bm | PR_HIRES_bm | PR_USART1_bm;
		PR.PRPD = PR_TWI_bm | PR_SPI_bm | PR_HIRES_bm;
		PR.PRPE = PR_TWI_bm | PR_SPI_bm | PR_HIRES_bm | PR_USART0_bm | PR_USART1_bm;
		PR.PRPF = PR_TWI_bm | PR_SPI_bm | PR_HIRES_bm | PR_USART0_bm | PR_USART1_bm | PR_TC1_bm;
	
		sei();		//Globale Interrupt einschalten
		PMIC.CTRL |= PMIC_HILVLEN_bm |PMIC_MEDLVLEN_bm|PMIC_LOLVLEN_bm;		//Alle Inerrupts aktivieren
		
		PORTA.DIRSET = Batt_FastCharge_bm;
		PORTA.OUTCLR = Batt_FastCharge_bm;			//Fastcharge off
}


void go_sleep(void)
{
	//PORTE.DIRCLR = Buzzer_bm;		//to avoid sounds while sleeping
	//interrupts aus
		TCF0.INTCTRLA = TC_OVFINTLVL_OFF_gc;	//OS Timer off
		TCD1.INTCTRLA = TC_OVFINTLVL_OFF_gc;	//Touch Timer off
		USARTD1.CTRLA = USART_RXCINTLVL_OFF_gc;	//Touch USART off
		PORTA.INTCTRL = PORT_INT0LVL_OFF_gc;	////BattStat off
	//Display sleep
		//Fade Backlight out
		unsigned char back_val = TCC0.CCA;
		for (TCC0.CCA ; TCC0.CCA > 0; TCC0.CCA--)
		{
			 _delay_ms(1);
		}
		tftEnterSleep();
		PORTC.DIRCLR = Display_Backlight_bm;
	//Sysclock auf 32KHz
		OSC.CTRL |= OSC_RC32KEN_bm;				//32KHz Oscillator einschalten
		while(!(OSC.STATUS & OSC_RC32KRDY_bm))	//Wenn Oscillator stabil wird das Flag RC32MRDY gesetzt und 32Mhz k�nnen benutzt werden
		{;}
		CCP = 0xD8;								//I/O Protection schutz aufheben f�r 4Cycles
		CLK.CTRL = CLK_SCLKSEL_RC32K_gc;		//Clock auf 2Mhz einstellen
		OSC.CTRL = OSC_RC32KEN_bm;				//Alle Clocks bis auf 32Khz ausschalten
	//Disable Periphery 
		/*
		PR.PRPA |= PR_ADC_bm;	
		PR.PRPC |= PR_USART0_bm | PR_TC0_bm | PR_TC1_bm;
		PR.PRPD |= PR_USART0_bm | PR_USART1_bm | PR_TC0_bm | PR_TC1_bm;
		PR.PRPE |= PR_TC0_bm | PR_TC1_bm;
		PR.PRPF |= PR_TC0_bm;
		*/
	//uC sleep	
		set_sleep_mode(SLEEP_MODE_IDLE);				//ca. 25mA Verbrauch mit aller Periphery aus
	
		PORTD.INTCTRL = PORT_INT0LVL_LO_gc;		//Touch Interrupt on falls er aus ist
		sleep_mode();							//uC sleep
		SLEEP.CTRL = 0;							//immediately after wake up set the Sleep Enable Bit to 0
	
	//---Wake Up
	//Enable Pheripherie 
		/*
		PR.PRPA &= ~PR_ADC_bm;	
		PR.PRPC &= ~(PR_USART0_bm | PR_TC0_bm | PR_TC1_bm);
		PR.PRPD &= ~(PR_USART0_bm | PR_USART1_bm | PR_TC0_bm | PR_TC1_bm);
		PR.PRPE &= ~(PR_TC0_bm | PR_TC1_bm);
		PR.PRPF &= ~PR_TC0_bm;
		*/
		Device_Init();							//Restore normal sys clock
		tftExitSleep();
	//Fade Backlight in
		_delay_ms(200);
		PORTC.DIRSET = Display_Backlight_bm;
		for (TCC0.CCA ; TCC0.CCA < back_val; TCC0.CCA++)
		{
			 _delay_ms(1);
		}
	//Interrupts enable
		TCF0.INTCTRLA = TC_OVFINTLVL_LO_gc;		//OS Timer on
		TCD1.INTCTRLA = TC_OVFINTLVL_LO_gc;		//Touch Timer on
		USARTD1.CTRLA = USART_RXCINTLVL_LO_gc;	//Touch USART on
		PORTA.INTCTRL = PORT_INT0LVL_LO_gc;		//BattStat on
		//PORTE.DIRSET = Buzzer_bm;
}