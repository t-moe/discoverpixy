extern void Device_Init(void);
extern void go_sleep(void);