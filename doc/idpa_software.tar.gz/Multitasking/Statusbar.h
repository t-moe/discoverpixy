extern void Statusbar_Init();
extern void Statusbar_Redraw();
extern void Time_Redraw();
extern void Statusbar_SetTitle(char* txt);
