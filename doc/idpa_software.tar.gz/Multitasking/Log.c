#include "settings.h"
#include "types.h"
#include "Tft/tft.h"
#include "Touch/touch.h"
#include "Log.h"


#define LOG_ENTRIES ((HEIGHT-32)/12)
char* logs[LOG_ENTRIES];
unsigned char log_start=0;
unsigned char log_cnt=0;
BOOL log_shown = FALSE;
//HACK Bad Memory Leaks!
void Log(char* str)
{
	unsigned char pos = log_start + log_cnt;
	if(pos>=LOG_ENTRIES)
		pos-=LOG_ENTRIES;
	logs[pos]=str;
	if(log_start==pos && log_cnt>0) //Overwrite a Entry
	{
		log_start++;
		log_shown=FALSE;
		Log_Show(); //Redraw All
	}	
	else 
	{
		tftPrint(5,32+log_cnt*12,WHITE,BLACK,SmallFont,str);
		log_cnt++;
	}	

	
}
void Log_Show()
{
	if(log_shown) return;
	tftFillRectangle(0,32,DWIDTH,DHEIGHT,BLACK);
	for(unsigned char i=0; i<log_cnt; i++)
	{
		unsigned char pos = log_start + i;
		if(pos>=LOG_ENTRIES)
			pos-=LOG_ENTRIES;
		tftPrint(5,32+i*12,WHITE,BLACK,SmallFont,logs[pos]);
	}
	log_shown=TRUE;
}
void Log_Hide()
{
	log_shown=FALSE;
}
void Log_TouchCB(void* touchArea, TOUCH_ACTION triggeredAction)
{
	Log("a");
}
TOUCH_AREA_STRUCT a;
void Log_Init()
{
	
	a.hookedActions=PEN_UP;
	a.x1=0;
	a.y1=0;
	a.x2=62;
	a.y2=31;
	a.callback = 	Log_TouchCB;
	touchRegisterArea(&a);
}