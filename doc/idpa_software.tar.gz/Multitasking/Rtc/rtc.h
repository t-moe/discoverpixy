
struct type_zeit
{   
    unsigned char sec;  //0..59
    unsigned char min;  //0..59
    unsigned char std;   //0..23
    unsigned char tag;  //1..31
    unsigned char monat; //1..12 
    unsigned char jahr;  //0..255 ab 2000
	unsigned char szeit;  // Sommer/Winterzeit 1/0 
	unsigned char wtag;  //Samstag =0 Freitag=6
};


//RTC Funktionen
extern void setTime(unsigned long *ticks);
extern void getTime(unsigned long* ticks);
extern void ticks2struct(unsigned long* ticks, struct type_zeit* stru);
extern void struct2ticks (struct type_zeit* stru,unsigned long* ticks);
extern void RTC_Init(void);
extern unsigned char getDaysOfMonth(unsigned char mon, unsigned char year);
extern unsigned char isSommerzeit(struct type_zeit* stru);
extern void Wochentag(struct type_zeit* stru);

extern const char * monate [12];   
extern const char * wochentage [7]; 
extern const char * wochentage_short [7];
extern struct type_zeit systime;