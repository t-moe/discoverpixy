/* �bernommen aus Privatprojekt */

#include "../settings.h"
#include "../types.h"
#include "../Alarm.h"
#include "../Statusbar.h"
#include "rtc.h"

#include "../PWM/PWM.h"
FLASH_INT_ARR( Alle_Meine_Entchen,) = {T_C5,1,T_D5,1,T_E5,1,T_F5,1,T_G5,2,T_G5,2,T_A5,1,T_A5,1,T_A5,1,T_A5,1,T_G5,4,T_A5,1,T_A5,1,T_A5,1,T_A5,1,T_G5,4,T_F5,1,T_F5,1,T_F5,1,T_F5,1,T_E5,2,T_E5,2,T_D5,1,T_D5,1,T_D5,1,T_D5,1,T_C5,4,T_Stopp};
FLASH_INT_ARR( Timo_0,) = {T_C5,4,T_G5,3,T_C5,4,T_G5,3,T_Pause,4,T_G4,4,T_D5,3,T_G4,4,T_D5,3,T_Pause,8,T_C6,12,T_Stopp};
	
/*-------------------------Konstanten--------------------------*/
//  m�ssen noch angepasst werden das sie im moment nicht konstant sind

 const char * monate []={"Januar","Februar","M�rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"};   
 const char * wochentage []={"Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag","Sonntag"}; 
 const char * wochentage_short []={"Mo","Di","Mi","Do","Fr","Sa","So"};
 const unsigned char mtab[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
/*--------------------------Anderes----------------------------*/

struct type_zeit systime = {0};

//BOOL oldSpez=0; 
//oldVariable zur Flankenerkennung der Winter/Sommerzeit umstellung


/*-----------------------Funktion setTime------------------------
* Beschreibung: Stellt die Zeit in der RTC auf die angegebene   *
*  Anzahl Sekunden (seit 1.1.2000 00:00). Zur Umrechnung einer	*
*  lesbaren Zeit, in diese Einheit kann struct2ticks verwendet	*
*  werden.														*
* Parameter:													*
*  ticks: Pointer auf die Anzahl Ticks							*
*    gespeichert als LONG (4bytes)								*
* R�ckgabewert: Keiner										    *
****************************************************************/
void setTime(unsigned long *ticks)
{
	while (RTC.STATUS & RTC_SYNCBUSY_bm);	//Aus Synchronit�t der RTC Register warten
	TCD0.CNT = (*ticks)>>16;				//Counter Register setzen
	RTC.CNT = *ticks;						//RTC Register setzen
}
/*-----------------------Funktion getTime------------------------
* Beschreibung: Liest die Anzahl Sekunden seit 1.1.2000 00:00   *
*  aus der RTC. Um diese Einheit in ein lesbares Format			*
*  umzurechnen, kann ticks2struct verwendet werden.  			*
* Parameter:													*
*  ticks: Pointer auf die Anzahl Ticks (LONG, 4bytes)			*
*   Die Zahl wird direkt in die �bergebene Variable geschrieben.*
* R�ckgabewert: Keiner										    *
****************************************************************/
void getTime(unsigned long* ticks)
{
	*ticks  = RTC.CNT & 0xFFFF;
	*ticks |= (long)TCD0.CNT << 16;
} 
/*--------------------Funktion isSommerzeit----------------------
* Beschreibung: Findet heraus ob sich der �bergebene Zeitpunkt  *
*  in der Sommerzeit oder Winterzeit befindet.   				*
* Parameter:													*
*  struc: Pointer auf Zeit&Datum								*
* R�ckgabewert: 1 = Sommerzeit  0 = Winterzeit				    *
****************************************************************/
unsigned char isSommerzeit(struct type_zeit* stru)
{
	if(	
	    (stru->monat > 3 || 
		 (stru->monat == 3 && stru->tag   > (31-((stru->jahr+5+(stru->jahr/4))%7)))) 
		 &&
		(stru->monat < 10 ||
		 (stru->monat == 10 && stru->tag   < (31-((stru->jahr+5+(stru->jahr/4))%7))))
	  )
		return 1;
	if(	(stru->monat==3) &&
		(stru->tag   == (31-((stru->jahr+5+(stru->jahr/4))%7))) &&
		(stru->std >= 2))
		return 1; 
	if(	(stru->monat==10) &&
		(stru->tag   == (31-((stru->jahr+5+(stru->jahr/4))%7))) &&
		(stru->std < 3))
		return 1; 
 	return 0;
}
/*----------------------Funktion Wochentag-----------------------
* Beschreibung: Findet den Wochentag des verwiesenen Datums   	*
*  heraus und speichert ihn in der Struktur (nebst Datum&Zeit). *
* Parameter:													*
*  struc: Pointer auf Zeit&Datum								*
* R�ckgabewert: Keiner										    *
****************************************************************/
void Wochentag(struct type_zeit* stru)
{
	unsigned int mon = stru->monat + 1;
	unsigned char year = stru->jahr;
	unsigned char year_K;
	unsigned char year_J;
	if(year==0 && mon <4)
	{
		year_K=99;
		year_J=19;
		mon+=12;
	}
	else
	{
		if(mon < 4)		   //eigentlich werden nur januar zu 13 und februar zu 14. aber in der formel muss sowieso noch 1 monat dazugez�hlt werden
		{
			mon+=12;
			year--;
		}
		year_K = year%100;
		year_J = 20 + year/100;
	}
	stru->wtag = (unsigned int)(stru->tag + ( mon*26/10) + year_K + (year_K/4) +(year_J/4) + 5* year_J)%7; 
	if(stru->wtag >= 2) // Mo-Fr
		stru->wtag -= 2;
	else
		stru->wtag+=5;
}
/*-------------------Funktion getDaysOfMonth---------------------
* Beschreibung: Gibt die Anzahl Tage zur�ck die ein Monat im    *
*  entsprechenden Jahr hat. (Unterschiedlich wegen Schaltjahr..)*
* Parameter:													*
*  mon: Der Index des Monats (1 = Januar .. 12 = Dezember)		*
*  year: Das ensprechende Jahr (0 = 2000 ..  255 = 2255)		*
* R�ckgabewert: Die Anzahl Tage die der Monat hat			    *
****************************************************************/
unsigned char getDaysOfMonth(unsigned char mon, unsigned char year)
{
	if(mon==2 && year%4==0)
		return 29;
	else return mtab[mon];
}
/*-------------------Funktion ticks2struct-----------------------
* Beschreibung: Rechnet die Anzahl Sekunden seit 1.1.2000 um in *
*  eine Zeit/Datum Struktur die f�r den Menschen lesbar ist     *
*  (inkl. Wochentag und Sommer/Winterzeit).					    *
* Parameter:													*
*  ticks: Pointer auf die Anzahl Ticks (LONG, 4bytes)			*
*  struc: Pointer auf Zeit&Datum (wird gef�llt)					*
* R�ckgabewert: Keiner										    *
****************************************************************/
void ticks2struct(unsigned long* ticks, struct type_zeit* stru)
{
	unsigned short days_sub=0;
	unsigned char monat_cnt = 0;
	unsigned long _ticks = *ticks;
	stru->jahr=0;
	while (_ticks >= (unsigned long) 3600 * 24 * 365)
	{
		if ( stru->jahr % 4 != 0) //Wenn kein Schaltjahr
			_ticks-=	(unsigned long) 3600 * 24 * 365; // 1 Jahr abziehen
		else if ( stru->jahr % 4 == 0  &&  _ticks >= (unsigned long)3600 * 24 * 366 ) //Schaltjahr
	    	_ticks -=  (unsigned long)3600 * 24 * 366; // 1 Schaltjahr abziehen
	  	else //Nicht mehr gen�gned Ticks vorhanden f�r Schaltjahr
	    	break; //While abbrechen
		stru->jahr++; //Struktur um 1 Jahr erh�hen
	}
	days_sub = _ticks/((unsigned long)3600 * 24); //Anzahl Tage die dieses Jahr bereits vergangen sind (wird automatich abgerundet) 
	_ticks -= (unsigned long) days_sub * ((unsigned long)3600 * 24); // Tage abziehen
	monat_cnt = 1;                           // Januar
	while (days_sub>=mtab[monat_cnt])          //Solange noch Tage auf die Monate verteilt werden k�nnen
	{
		if (monat_cnt == 2) // Februar
		{            
			if (( (stru->jahr % 4) == 0)) 
			//4 teilbar  = Schaltjahr	
			{
				if(days_sub>=29) days_sub -=29;
				else break;//Keine Tage mehr zu verteilen
			}
			else days_sub-=28; // Kein Schaltjahr	
		}
		else days_sub -= mtab[monat_cnt];
		//Angenommen es ist der 1. Feburar so wird days_sub auf 31 sein und es m�ssen 31 tage abgezogen werden um auf den Monat Februar zu kommen
	 	monat_cnt++; //Gehe zum n�chsten Monat
	} 
	stru->monat= monat_cnt; //Anzahl Monate Setzen
	stru->tag = days_sub + 1; //Was noch nicht abgezogen wurde, sind die �brigbleibenden Tage
	stru->std = _ticks / 3600; //Anzahl Stunden setzen
	if(isSommerzeit(stru))
	{
		stru->szeit=1; //Sommerzeit
		stru->std++; 
		if ( stru->std == 24 )
        {					   
        	stru->std = 0;
			stru->tag++;
			if(stru->tag>getDaysOfMonth(stru->monat, stru->jahr))
			{
				stru->tag=1;
				stru->monat++;
				if(stru->monat==13)
				{
					stru->monat=1;
					stru->jahr++;
				}
			}	
			Wochentag(stru);
		}  	
	}
	else stru->szeit=0; //Winterzeit		 
	Wochentag(stru);
	_ticks %= 3600;	//Nur Minuten und Sekunden lassen
	stru->min= _ticks / 60; //60 Sekunden pro Minute
	stru->sec = _ticks % 60; //Rest	
}
/*-------------------Funktion struct2ticks-----------------------
* Beschreibung: Rechnet eine Zeit/Datum Struktur um in die      *
*  Anzahl Sekunden die seit 1.1.2000 vergangen sind.			*
* Parameter:													*
*  struc: Pointer auf Zeit&Datum.								*
*  ticks: Pointer auf die Anzahl Ticks (wird gef�llt)			*
* R�ckgabewert: Keiner										    *
****************************************************************/
void struct2ticks (struct type_zeit* stru,unsigned long* ticks)
{ 
	unsigned char monat_cnt = 0;
	unsigned char jahr_cnt = 0;
	unsigned long days_add = 0;
	unsigned long _ticks  = stru->sec; 
	_ticks  += stru->min * 60;
	_ticks  += (unsigned long) stru->std * 3600;
	days_add =  stru->tag-1;	//Restliche Tage des Monats (ohne Heute)
	monat_cnt = 1;                           // Januar
	while (monat_cnt < stru->monat)          // Alle Monate bis zum jetzigen
		days_add += getDaysOfMonth(monat_cnt++,stru->jahr); 
   	_ticks += (unsigned long) days_add * 3600 * 24; //Tage dieses Jahres hinzuf�gen
   	if(stru->szeit) //Sommerzeit
   		_ticks -=3600;	//1 Stunde abziehen (die Ticks werden in Winterzeit berechnet)
	//Tage wurden hinzugef�gt
	//Als Basis wird Jahr 2000 genommen
	days_add = (unsigned long)365 * stru->jahr;  // F�r jedes vergangene Jahr werden 365 Tage addiert
 	jahr_cnt=0;  //Jahr 2000 war ein schaltjahr, also beginnen wir dort
   	while (jahr_cnt < stru->jahr) //F�r jedes Jahr seit 2001 ohne aktuelles Jahr        
	{
       	if (jahr_cnt % 4 == 0)  //War ein Schaltjahr
	   		days_add++;	//F�ge 1 Tag hinzu -> 365 + 1 = 366
		jahr_cnt++;
   	}
   	_ticks += (unsigned long) days_add * 3600 * 24; //Tage der vergangenen Jahre hinzuf�gen
	*ticks=_ticks;
}
//Funktion Time2struct
//wandelt die gegebene Zeit in ein struc vom Typ type_zeit um

void Time2struct(struct type_zeit* stru, char currTime[], char currDate[])
{	 
	 if (currDate[4]==' ')
	 stru->tag	  =  (currDate[5]-'0');
	 else
	 stru->tag	 = (currDate[4]-'0')*10 + (currDate[5]-'0');
	 
	 stru->jahr = (currDate[8]-'0')*100+ (currDate[9]-'0')*10 + (currDate[10]-'0');
	 
	 stru->std  = (currTime[0]-'0')*10 + (currTime[1]-'0');
	 stru->min  = (currTime[3]-'0')*10 + (currTime[4]-'0');
	 stru->sec  = (currTime[6]-'0')*10 + (currTime[7]-'0');
	 
	switch (currDate[0])
	{
		case 'J': 
			switch (currDate[2])
			{
				case 'n': 
					if (currDate[1]=='a')
						stru->monat = 1;
					else
						stru->monat = 6;
					break;
				default:
					stru->monat = 7;
					break;
			}
			break;
		case 'F':
			stru->monat = 2;
			break;
		case 'M':
			if (currDate[2]=='r')
			{
				stru->monat = 3;
			}
			else
			{
				stru->monat = 5;
			}			
			break;
		case 'A':
			if (currDate[2]=='g')
			{
				
				stru->monat = 8;
			}
			else
			{
				stru->monat = 4;
			}			
			break;	
		case 'S':
			stru->monat = 9;
			break;	
		case 'O':
			stru->monat = 10;
			break;	
		case 'N':
			stru->monat = 11;
			break;
		default:
			stru->monat = 12;
			break;
	}
	stru->szeit=isSommerzeit(stru);
}
/*---------------------Funktion RTC_INIT-------------------------
* Beschreibung: Initialisiert die RTC, stellt sie auf die 		*
*  Kompilierzeit (falls keine andere Zeit vorhanden) und f�llt  *
*  die Zeit/Datum Struktur "Zeit" (aktuelle Zeit) mit den       *
*  richtigen Werten											    *
* Parameter: Keine												*
* R�ckgabewert: Keiner										    *
****************************************************************/

void RTC_Init(void)
{
		struct type_zeit t;
		unsigned long ticks;
		
		//RTC///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//RTC aktivieren (internet Quarz)
		//OSC.CTRL |= OSC_RC32KEN_bm;		//32KHz Oscillator einschalten BIT2 = OSC_RC32KEN wird gesetzt
		//while(!(OSC.STATUS & OSC_RC32KRDY_bm)) //Wenn interner Oscillator stabil wird das Flag RC32KRDY gesetzt und 32Khz k�nnen benutzt werden
		//{;}
		//CLK.RTCCTRL |= CLK_RTCSRC_RCOSC_gc;	//RTC Taktquelle auf internen 32.768KHz/32 Oszillator einstellen = 1.024KHz
		
		//RTC aktivieren (externer Quarz)
		OSC.XOSCCTRL |= OSC_XOSCSEL1_bm;	//32KHz externen Oscillator einschalten BIT2 = OSC_RC32KEN wird gesetzt
		CLK.RTCCTRL |= CLK_RTCSRC_TOSC_gc;		//RTC Taktquelle auf externen 32.768KHz/32 Oszillator einstellen = 1.024KHz		
		CLK.RTCCTRL |= CLK_RTCEN_bm;		//RTC enable
		
		//RTC einstellen
		RTC.CTRL = RTC_PRESCALER_DIV1024_gc;	//RTC Clock durch 1024 teilen = 1Hz
		//while (RTC.STATUS & RTC_SYNCBUSY_bm);
		//RTC.PER = 5000;		//Die RTC soll nach 12h �berlaufen
		//while (RTC.STATUS & RTC_SYNCBUSY_bm);
		//RTC.COMP = 65535;	//Compare Register f�r Alarm o.�*/

		//RTC.INTCTRL |= RTC_COMPINTLVL0_bm;		//Compare Match Interrupt
		
		//MANNNN EVENTSYSTEM !!!!!!!!!!!!!!!!
		//Init Event System
		EVSYS.CH0MUX = EVSYS_CHMUX_RTC_OVF_gc;					//Event Channel 0 wird bei RTC overflow ausgel�st
		TCD0.CTRLA = TC_CLKSEL_EVCH0_gc;						//Counter D0 CLK Source auf Event Channel 0
		TCD0.CTRLD = TC_EVACT_UPDOWN_gc | TC_EVSEL_CH0_gc;		//Counter z�hlt up oder down | Event Channel 0
		
		Time2struct(&t,__TIME__,__DATE__);
		struct2ticks(&t,&ticks);
		setTime(&ticks);
}  
ALARM_STRUCT* active_alarm;
void set_alarm(ALARM_STRUCT* alarm)
{
	struct type_zeit time_act;
	unsigned long ticks_act;
	active_alarm=alarm;
	//aktuelle Zeit lesen
	getTime(&ticks_act);
	ticks2struct(&ticks_act,&time_act);
	
	//�berpr�fen ob die Alarm Zeit schon vergangen ist
	if (time_act.std > alarm->hour)
		time_act.tag++;					//ACHTUNG!!!!!!   bei monats�berlauf
	else if (time_act.std == alarm->hour)
		{	
			if (time_act.min >alarm->min)
				time_act.tag++;					//ACHTUNG!!!!!!   bei monats�berlauf
		}
	//Alarm Zeit ins struct schreiben
	time_act.std = alarm->hour;
	time_act.min = alarm->min;
	time_act.sec = 0;
	struct2ticks(&time_act,&ticks_act);
	//Alarm Zeit setzen
	while (RTC.STATUS & RTC_SYNCBUSY_bm);
	RTC.COMP = (0xFFFF & ticks_act);	//Compare Register f�r Alarm o.�
	RTC.INTCTRL |= RTC_COMPINTLVL_LO_gc;		//Compare Match Interrupt
}


ISR (RTC_COMP_vect)
{
	unsigned long ticks_act;
	struct type_zeit time_act;
	
	getTime(&ticks_act);
	ticks2struct(&ticks_act,&time_act);
	
	if (active_alarm->hour == time_act.std &&
		active_alarm->min == time_act.min &&
		(active_alarm->flags & ALARM_ENABLE) &&
		(active_alarm->flags & (ALARM_MO << time_act.wtag)))
	{
		Melody_Start(Timo_0);//Melodie abspielen
		RTC.INTCTRL |= RTC_COMPINTLVL_OFF_gc;		//Compare Match Interrupt
	}	
	
	 Time_Redraw();
}

/*
void set_alarm (ALARM_STRUCT* alarm) 
{
	struct type_zeit time_act;
	unsigned long ticks_act;
	unsigned char wochtag;
	getTime(&ticks_act);
	//n�chsten Alarmtag ausrechnen
	ticks2struct(&ticks_act,&time_act);
	
	for (wochtag=time_act.wtag ;0 == (alarm->flags&(1<<wochtag)) ;wochtag++)
	{
		//wochtag++;
		//time_act.wtag++;
	}
	
	ticks_act += (long)3600*24*wochtag;
	ticks2struct(&ticks_act,&time_act);
	time_act.std = alarm->hour;
	time_act.min = alarm->min;
	struct2ticks(&time_act,&ticks_act);
	
	while (RTC.STATUS & RTC_SYNCBUSY_bm);
	RTC.COMP = ticks_act;	//Compare Register f�r Alarm o.�
	
	// bla = alarm->hour;
	//struct2ticks(&time,&ticks)
	//RTC.CNT = *ticks;						//RTC Register setzen
	
}*/
