/*
 * PWM.c
 *
 * Created: 03.01.2012 12:39:12
 *  Author: Excalibur
 */ 
#include "../settings.h"
#include "../types.h"
#include "../OpSys/timer.h"
#include "PWM.h"


TIMER_STRUCT* MELODY_TIMER;	

unsigned int Zeit;
unsigned char Arr_pos;	
FLASH_INT_ARR_POINTER MelodyPointer;
	
//Spielt eine Melodie ab
void Melody_Timer_Run(void* Timer)
{
	Zeit++;
	if (Zeit==FLASH_INT_ARR_READ(&MelodyPointer[Arr_pos+1]))	//wenn Abspielzeit erreicht
	{
		Zeit=0;
		Arr_pos += 2;					//n�chsten Ton abspielen
		if ((FLASH_INT_ARR_READ(&MelodyPointer[Arr_pos])+FLASH_INT_ARR_READ(&MelodyPointer[Arr_pos+1]))==0)	//Auf Melodieende �berpr�fen
		{
			Set_Tone(0);
			Timer_Stop(MELODY_TIMER);			//Timer stoppen
			Arr_pos=0;
		}
		else
		{
			Set_Tone(0);
			_delay_ms(30); //We should fix that 
			Set_Tone(FLASH_INT_ARR_READ(&MelodyPointer[Arr_pos]));
		}		
	}
}

void Melody_Start(FLASH_INT_ARR_POINTER melody)
{
	MelodyPointer=melody;
	Timer_Start(MELODY_TIMER);
	Set_Tone(FLASH_INT_ARR_READ(&MelodyPointer[0]));
	//PORTE.DIRSET = Buzzer_bm;
}


void Set_Tone(unsigned int freq)
{
	PORTE.DIRCLR = Buzzer_bm;			//Buzzer aus
	TCE0.CCA = freq;	//Neue Frequenz einstellen
	if (TCE0.CCA!=0)					//Falls keine Pause 
		PORTE.DIRSET = Buzzer_bm;			//Buzzer ein
}
void PWM_Init (void)
{
	//PWM Display Backlight
		//PWM0 PortC Pin 0
		TCC0.CTRLA = TC_CLKSEL_DIV8_gc;				//Counter Prescaler
		TCC0.CTRLB |= 0x10 | TC_WGMODE_SS_gc;		//PWM on Channel A Enable and Single Slope PWM
		TCC0.PER = 0xFF;							//MAX counter Value is 0xFF = 8Bit PWM
		TCC0.CCA = 0x00;							//Set compare Register		//ca. 80% Helligkeit
		PORTC.PIN0CTRL |= PORT_INVEN_bm;			//Invert Pin
		PORTC.DIRSET = Display_Backlight_bm;
	//PWM LED
		//PWM1 PortC Pin 4
		TCC1.CTRLA = TC_CLKSEL_DIV8_gc;				//Counter Prescaler
		TCC1.CTRLB |= 0x10 | TC_WGMODE_SS_gc;		//PWM on Channel A Enable and Single Slope PWM
		TCC1.PER = 0xFF;							//MAX counter Value is 0xFF = 8Bit PWM
		TCC1.CCA = 0x00;							//Set compare Register
		PORTC.PIN4CTRL |= PORT_INVEN_bm;			//Invert Pin
		PORTC.DIRSET = LED_bm; 
	//Frequency Buzzer
		//Freq0 PortE Pin 0
		TCE0.CTRLA = TC_CLKSEL_DIV8_gc;				//Counter Prescaler
		TCE0.CTRLB |= 0x10 | TC_WGMODE_FRQ_gc;		//PWM on Pin0 enable and set Dual Slope PWM
													//MAX counter Value is 0xFFFF = 16Bit Freq
		//TCE0.CCA = 0x0000;							//Set compare Register
		//PORTE.DIRSET = Buzzer_bm;				//Enable Buzzer Driver
		
		
	 MELODY_TIMER= Timer_Add(50,10,Melody_Timer_Run);
}


//Fadet das Backlight zum gew�nschten Wert
void Fade_Backlight (unsigned char Helligkeit)
{
	if (Helligkeit==TCC0.CCA)
	;
	else if (Helligkeit>TCC0.CCA)
		TCC0.CCA ++;
	else
		TCC0.CCA --;
}
//Setzt das Backlight auf den gew�nschten Wert
void Set_Backlight (unsigned char Helligkeit)
{
	TCC0.CCA = Helligkeit;
}
//Fadet die LED zum gew�nschten Wert
void Fade_LED (unsigned char Helligkeit)
{
	if (Helligkeit==TCC1.CCA)
	;
	else if (Helligkeit>TCC1.CCA)
		TCC1.CCA ++;
	else
		TCC1.CCA --;
}
//Setzt die LED auf den gew�nschten Wert
void Set_LED (unsigned char Helligkeit)
{
	TCC1.CCA = Helligkeit;
}
