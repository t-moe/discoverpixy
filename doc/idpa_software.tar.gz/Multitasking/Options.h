/*
 * Options.c
 *
 * Created: 28.01.2012 20:25:45
 *  Author: Excalibur
 */ 

extern void Options_Show(void);
extern void Options_Hide(void);