/*
 * Mainmenu.c
 *
 * Created: 28.01.2012 16:59:15
 *  Author: Excalibur
 */ 
#include "settings.h"
#include "types.h"
#include "Tft/tft.h"
#include "Touch/touch.h"
#include "Gui/button.h"
#include "Alarm.h"
#include "Statusbar.h"
#include "Device/device.h"
#include "PWM/PWM.h"
#include <stdlib.h>
#include "Mainmenu.h"
#include "Options.h"
#include "OptionsTime.h"
#include "Schlafkurve.h"


BITMAPBUTTON_STRUCT* mm_buttons;

void mmb_cb_wecker(void* button)
{ 
	Mainmenu_Hide();
	uiAlarmShowAll();
}
void mmb_cb_skurve(void* button)
{ 
	Mainmenu_Hide();
	uiGraphShow();
}
void mmb_cb_standby(void* button)
{ 
	go_sleep();
}
void mmb_cb_einstellungen(void* button)
{ 
	Mainmenu_Hide();
	Options_Show();
}



void Mainmenu_Show(void)
{
	Statusbar_SetTitle("Hauptmen�");
	tftDrawLinearGradient(0, 32,WIDTH, HEIGHT-32,  HEX(0x65EAFF),HEX(0x6C65FF),TOP_BOTTOM);
	mm_buttons = malloc(sizeof(BITMAPBUTTON_STRUCT)*4);
	
	//Wecker
	mm_buttons[0].base.x1=10; //Start X of Button
	mm_buttons[0].base.y1=31+ 10; //Start Y of Button
	mm_buttons[0].base.x2=mm_buttons[0].base.x1 + 183 -1 +2; //Auto Calculate X2 with String Width
	mm_buttons[0].base.y2=mm_buttons[0].base.y1 + 87 -1 +2; //Auto Calculate Y2 with String Height
	mm_buttons[0].bgcolor = RGB(100,100,100);
	mm_buttons[0].imgwidth=183;
	mm_buttons[0].imgheight=87;
	mm_buttons[0].filename = "Alrm.raw";
	mm_buttons[0].callback=mmb_cb_wecker; //Call b1_cb as Callback
	guiAddBitmapButton(&mm_buttons[0]); //Register Button (and run the callback from now on)
	
	//Schlafkurve
	mm_buttons[1].base.x1=205; //Start X of Button
	mm_buttons[1].base.y1=31+ 10; //Start Y of Button
	mm_buttons[1].base.x2=mm_buttons[1].base.x1 + 183 -1 +2; //Auto Calculate X2 with String Width
	mm_buttons[1].base.y2=mm_buttons[1].base.y1 + 87 -1 +2; //Auto Calculate Y2 with String Height
	mm_buttons[1].bgcolor = RGB(100,100,100);
	mm_buttons[1].imgwidth=183;
	mm_buttons[1].imgheight=87;
	mm_buttons[1].filename = "Grph.raw";
	mm_buttons[1].callback=mmb_cb_skurve; //Call b1_cb as Callback
	guiAddBitmapButton(&mm_buttons[1]); //Register Button (and run the callback from now on
	
	//Standby
	mm_buttons[2].base.x1=10; //Start X of Button
	mm_buttons[2].base.y1=139; //Start Y of Button
	mm_buttons[2].base.x2=mm_buttons[2].base.x1 + 183 -1 +2; //Auto Calculate X2 with String Width
	mm_buttons[2].base.y2=mm_buttons[2].base.y1 + 87 -1 +2; //Auto Calculate Y2 with String Height
	mm_buttons[2].bgcolor = RGB(100,100,100);
	mm_buttons[2].imgwidth=183;
	mm_buttons[2].imgheight=87;
	mm_buttons[2].filename = "Stby.raw";
	mm_buttons[2].callback=mmb_cb_standby; //Call b1_cb as Callback
	guiAddBitmapButton(&mm_buttons[2]); //Register Button (and run the callback from now on)
	
	//Einstellugen
	mm_buttons[3].base.x1=205; //Start X of Button
	mm_buttons[3].base.y1=139; //Start Y of Button
	mm_buttons[3].base.x2=mm_buttons[3].base.x1 + 183 -1 +2; //Auto Calculate X2 with String Width
	mm_buttons[3].base.y2=mm_buttons[3].base.y1 + 87 -1 +2; //Auto Calculate Y2 with String Height
	mm_buttons[3].bgcolor = RGB(100,100,100);
	mm_buttons[3].imgwidth=183;
	mm_buttons[3].imgheight=87;
	mm_buttons[3].filename = "Sngs.raw";
	mm_buttons[3].callback=mmb_cb_einstellungen; //Call b1_cb as Callback
	guiAddBitmapButton(&mm_buttons[3]); //Register Button (and run the callback from now on)
}
void Mainmenu_Hide(void)
{
	guiRemoveBitmapButton(&mm_buttons[0]);
	guiRemoveBitmapButton(&mm_buttons[1]);
	guiRemoveBitmapButton(&mm_buttons[2]);
	guiRemoveBitmapButton(&mm_buttons[3]);
	free(mm_buttons);
}