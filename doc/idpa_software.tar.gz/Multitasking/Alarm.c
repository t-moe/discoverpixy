#include "settings.h"
#include "types.h"
#include "tft/tft.h"
#include "Rtc/rtc.h"
#include "touch/touch.h"
#include "Gui/button.h"
#include "Gui/checkbox.h"
#include "Gui/softinput.h"
#include "Alarm.h"
#include "Statusbar.h"
#include "Mainmenu.h"
#include <ctype.h> //for softinput
#include <string.h>
#include <stdlib.h>


extern void set_alarm(ALARM_STRUCT* alarm);


#define NUM_ALARMS 4

#define C_INACTIVE HEX(0x2E90BD)
#define C_ACTIVE HEX(0x95C265)
#define C_TEXT WHITE

#define C_TEXT_HIGHLIGHTED HEX(0xF2F4F5)

#define C_BG_INACTIVE_TOP HEX(0x3B6BFF)
#define C_BG_INACTIVE_BOT HEX(0xB7C9FF)
#define C_BG_ACTIVE_TOP HEX(0x0ACB6B)
#define C_BG_ACTIVE_BOT HEX(0xD8F6E7)

#define xstr(s) str(s)
#define str(s) #s

static ALARM_STRUCT * cur_alarm;	 
static BUTTON_STRUCT*  b_buttons;
static TOUCH_AREA_STRUCT* ta_touchareas;
static CHECKBOX_STRUCT* cb_alarm_en;
static unsigned char hour;
static unsigned char min;

static enum {K_NONE,K_NAME,K_TIME_HOUR,K_TIME_MINUTE}activeKeyboard;

static char* buf; //[ALARM_NAME_MAXLENGTH+1]
static unsigned char buf_ind=0;
static char * allkeys []  ={
	"Q","W","E","R","T","Z","U","I","O","P","",
	"A","S","D","F","G","H","J","K","L","^","",
	"Y","X","C","V","B","N","M"," ","<-","",
	""
};


static void soft_cb(char** b, unsigned char ind_nospace,unsigned char ind_spaced)
{
	if(b == allnums)
	{
		if(activeKeyboard==K_TIME_HOUR)
		{
			if(hour>=10) hour%=10;
			hour*=10;
			hour+=b[ind_spaced][0] -48; //48 = Asci '0'
			tftPrintf_P(10 + 5 * 16 + 10 + 8,106 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%02u"),hour);
		}	
		else
		{
			if(min>=10) min%=10;
			min*=10;
			min+=b[ind_spaced][0]-48; //48 = Asci '0'
			tftPrintf_P(10 + 5 * 16 + 10 + 8 + 3*16,106 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%02u"),min);
		}	
		
	}
	else
	{
		if(b[ind_spaced][0]=='<')
		{
			if(buf_ind>0)
			 buf[--buf_ind]=0;
		}
		else if (b[ind_spaced][0]=='^')
		{
			unsigned char cnt=0;
			BOOL tUp= islower( b[0][0]);
			while(1)
			{
				if(b[cnt][0]!=0)
				{
					if(tUp) b[cnt][0]=toupper(b[cnt][0]);
					else b[cnt][0]=tolower(b[cnt][0]);
				}
				else if(b[cnt+1][0]==0) break;
				cnt++;	
			}
			guiUpdateSoftInput();
		}
		else if(buf_ind<ALARM_NAME_MAXLENGTH)
		{
 			buf[buf_ind++]=b[ind_spaced][0];
			buf[buf_ind]=0;
		}
		tftPrintf_P(10 + 5 * 16 + 10 + 8,66 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%-"xstr(ALARM_NAME_MAXLENGTH)"s"),buf);
		//macro xstr converts the value of the define into a string. See: http://gcc.gnu.org/onlinedocs/cpp/Stringification.html#Stringification
	}
}

static void ta_fullspace_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NAME)
	{
		activeKeyboard = K_NONE;
		guiRemoveSoftInput();
		unsigned char i=0;
		while(1)
		{
			if(buf[i]!=' ')
				break;
			i++;
		}
		if(buf[i]==0)
			strcpy(buf,"Alarm 1");
		
		tftPrintf_P(10 + 5 * 16 + 10 + 8,66 + 8,BLACK,WHITE,BigFont,PSTR("%-"xstr(ALARM_NAME_MAXLENGTH)"s"),buf);
		tftFillRectangle(0,DHEIGHT-95,DWIDTH,DHEIGHT,HEX(0x65EAFF));	
		tftPrint_P(10,146+3,BLACK,TRANSPARENT,BigFont,PSTR("Tage:"));
		for(unsigned char i=0; i<9; i++) //For all 7 Wday buttons + ok & cancel
		{
			guiAddButton(&b_buttons[i]);
			guiRedrawButton(&b_buttons[i]);
		}	
	}
	else if(activeKeyboard!=K_NONE)
	{
		if(hour>23) hour=23;
		if(min>59) min = 59;
		tftPrintf_P(10 + 5 * 16 + 10 + 8,106 + 8,BLACK,WHITE,BigFont,PSTR("%02u:%02u"),hour,min);
		activeKeyboard = K_NONE;
		guiRemoveSoftInput();
		tftFillRectangle(0,DHEIGHT-40,DWIDTH,DHEIGHT,HEX(0x65EAFF));	
		
		guiAddButton(&b_buttons[7]); // b_alarm_ok
		guiAddButton(&b_buttons[8]); // b_alarm_cancel	
		guiRedrawButton(&b_buttons[7]);
		guiRedrawButton(&b_buttons[8]);
	}

}
static void ta_name_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		buf_ind=0;
		buf[0]=0;
		tftPrintf_P(10 + 5 * 16 + 10 + 8,66 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("%-"xstr(ALARM_NAME_MAXLENGTH)"s"),buf);
		for(unsigned char i=0; i<9; i++) //For all 7 Wday buttons + ok & cancel
			guiRemoveButton(&b_buttons[i]);
		activeKeyboard = K_NAME;
		ta_touchareas[0].y2=DHEIGHT-95; //ta_fullspace
		guiAddSoftInput(allkeys,95,soft_cb);
	}
}

static void ta_hour_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		hour=0;
		tftPrint_P(10 + 5 * 16 + 10 + 8,106 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("  "));
		guiRemoveButton(&b_buttons[7]); // b_alarm_ok
		guiRemoveButton(&b_buttons[8]); // b_alarm_cancel	
		activeKeyboard = K_TIME_HOUR;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}
static void ta_min_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	if(activeKeyboard==K_NONE)
	{
		min=0;
		tftPrint_P(10 + 5 * 16 + 10 + 8 + 3 * 16,106 + 8,BLACK,C_TEXT_HIGHLIGHTED,BigFont,PSTR("  "));
		guiRemoveButton(&b_buttons[7]); // b_alarm_ok
		guiRemoveButton(&b_buttons[8]); // b_alarm_cancel	
		activeKeyboard = K_TIME_MINUTE;
		ta_touchareas[0].y2=DHEIGHT-40;//ta_fullspace
		guiAddSoftInput(allnums,40,soft_cb);
	}
}

static void ui_alarm_wday_cb(void* button)
//Same callback for all 7 Wday-Buttons
//Api is cool, isn't it :) ?
{
	BUTTON_STRUCT * b = (BUTTON_STRUCT*) button;
	if(b->bgcolor==C_ACTIVE)
		b->bgcolor = C_INACTIVE;
	else
		b->bgcolor = C_ACTIVE;
	set_alarm(cur_alarm);
	guiRedrawButton(b);
}

static void b_alarm_cancel_cb(void* button)
{
	guiRemoveCheckbox(cb_alarm_en);
	for(unsigned char i=0; i<9; i++)
		guiRemoveButton(&b_buttons[i]);
	for(unsigned char i=0; i<4; i++)	
		touchUnregisterArea(&ta_touchareas[i]);
	free(ta_touchareas);
	free(b_buttons);
	free(cb_alarm_en);
	free(buf);


	uiAlarmShowAll();
}

extern void set_alarm(ALARM_STRUCT* alarm);
static void b_alarm_ok_cb(void* button)
{
	cur_alarm->hour = hour;
	cur_alarm->min=min;
	unsigned char fl=  (cb_alarm_en->checked)?ALARM_ENABLE:0;
	for(unsigned char i=0; i<7; i++) //For all 7 wday buttons
	{
		if(b_buttons[i].bgcolor==C_ACTIVE)
			fl|=ALARM_MO<<i;
	}
	cur_alarm->flags = fl;
	strcpy (cur_alarm->name, buf );
	
	set_alarm(cur_alarm);
	/*set_alarm(cur_alarm); //Test Rtc
	go_sleep();*/
	
	b_alarm_cancel_cb(&b_buttons[8]);
}


void uiAlarmShow(ALARM_STRUCT* alarm)
{
	activeKeyboard = K_NONE;
	buf_ind=0;
	hour=alarm->hour;
	min=alarm->min;
	cur_alarm = alarm;
	//Reserve Dynamic Memory
	ta_touchareas = malloc(sizeof(TOUCH_AREA_STRUCT)*4);
	b_buttons = malloc(sizeof(BUTTON_STRUCT)*9);
	cb_alarm_en = malloc(sizeof(CHECKBOX_STRUCT));
	buf = malloc(ALARM_NAME_MAXLENGTH+1);
	strcpy ( buf,alarm->name );
	
	
	Statusbar_SetTitle("Wecker bearbeiten");
	tftFillRectangle(0,32,DWIDTH,DHEIGHT,HEX(0x65EAFF)); //draw BG

	//Touch Area for FullSpace without Statusbar and Softinput
	ta_touchareas[0].x1=0; //Start X of Area
	ta_touchareas[0].y1=32; //Start Y of Area
	ta_touchareas[0].x2=DWIDTH; //End X of Area
	ta_touchareas[0].y2=32; //End Y of Area -> Will be changed before softinput opens
	ta_touchareas[0].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[0].callback =ta_fullspace_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[0]); //Register Area (and run the callback from now on)
	
	
	//Checkbox for Enable
	unsigned char y = 42;
	tftPrint_P(10,y ,BLACK,TRANSPARENT,BigFont,PSTR("Wecker einschalten:"));
	cb_alarm_en->base.x1 = 10 + 19*16 + 10 ;
	cb_alarm_en->base.y1 = y ; 
	cb_alarm_en->base.x2 = cb_alarm_en->base.x1 + 16; 
	cb_alarm_en->base.y2=0;
	cb_alarm_en->fgcolor =  CHECKBOX_WIN_FG_COLOR;
	cb_alarm_en->checked = alarm->flags & ALARM_ENABLE ;
	cb_alarm_en->callback = NULL;
	guiAddCheckbox(cb_alarm_en);
	
	//Alarm Name
	y+=24;
	tftPrint_P(10,y + 7 ,BLACK,TRANSPARENT,BigFont,PSTR("Name:"));
	tftFillRectangle(10 + 5 * 16 + 10,y,DWIDTH-8,y +31,WHITE);
	tftDrawRectangle(10 + 5 * 16 + 10,y,DWIDTH-8,y+ 31,BLACK);
	tftPrintf(10 + 5 * 16 + 10 + 8,y + 8,BLACK,WHITE,BigFont,alarm->name);
	
	//ta_name
	ta_touchareas[1].x1=10 + 5 * 16 + 10; //Start X of Area
	ta_touchareas[1].y1=y; //Start Y of Area
	ta_touchareas[1].x2=DWIDTH-8; //End X of Area
	ta_touchareas[1].y2=y +31; //End Y of Area
	ta_touchareas[1].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[1].callback =ta_name_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[1]); //Register Area (and run the callback from now on)
	
	//Alarm Time
	y+=32+8;
	tftPrint_P(10,y +7 ,BLACK,TRANSPARENT,BigFont,PSTR("Zeit:"));
	tftFillRectangle(10 + 5 * 16 + 10,y,DWIDTH-8,y +31,WHITE);
	tftDrawRectangle(10 +5 * 16 + 10,y,DWIDTH-8,y+ 31,BLACK);
	tftPrintf_P(10 + 5 * 16 + 10 + 8,y + 8,BLACK,WHITE,BigFont,PSTR("%02u:%02u"),alarm->hour,alarm->min);
	
	//ta_hour
	ta_touchareas[2].x1=10 +5 * 16 + 10; //Start X of Area
	ta_touchareas[2].y1=y; //Start Y of Area
	ta_touchareas[2].x2=ta_touchareas[2].x1+40; //End X of Area
	ta_touchareas[2].y2=ta_touchareas[2].y1 +31; //End Y of Area
	ta_touchareas[2].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[2].callback =ta_hour_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[2]); 
	
	//ta_min
	ta_touchareas[3].x1=ta_touchareas[2].x2+1; //Start X of Area
	ta_touchareas[3].y1=y; //Start Y of Area
	ta_touchareas[3].x2=ta_touchareas[3].x1+40; //End X of Area
	ta_touchareas[3].y2=ta_touchareas[3].y1 +31; //End Y of Area
	ta_touchareas[3].hookedActions= PEN_DOWN; //Select Interrupt Sources
	ta_touchareas[3].callback =ta_min_cb; //Call a1_cb as Callback
	touchRegisterArea(&ta_touchareas[3]); 
	
	
	//Alarm Days
	y+=32+8;
	tftPrint_P(10,y+3,BLACK,TRANSPARENT,BigFont,PSTR("Tage:"));
	for(unsigned char i=0; i<7; i++) //For all 7 wday buttons
	{
		b_buttons[i].base.x1=10 +5 * 16 + 10 + i*42; //Start X of Button
		b_buttons[i].base.y1=y; //Start Y of Button
		b_buttons[i].base.x2=AUTO; //Auto Calculate X2 with String Width
		b_buttons[i].base.y2=AUTO; //Auto Calculate Y2 with String Height
		b_buttons[i].txtcolor=C_TEXT; //Set foreground color
		if(alarm->flags&(ALARM_MO<<i))
			b_buttons[i].bgcolor=C_ACTIVE; //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
		else
			b_buttons[i].bgcolor=C_INACTIVE; //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
		b_buttons[i].font=BigFont; //Select Font
		b_buttons[i].text=(char *)wochentage_short[i]; //Set Text (For formatted strings take sprintf)
		b_buttons[i].callback=ui_alarm_wday_cb; //Call b1_cb as Callback
		guiAddButton(&b_buttons[i]); //Register Button (and run the callback from now on)
	}
		
		
	//b_alarm_ok	
	b_buttons[7].base.x1=25; //Start X of Button
	b_buttons[7].base.y1=DHEIGHT - 30; //Start Y of Button
	b_buttons[7].base.x2=b_buttons[7].base.x1+160; //Auto Calculate X2 with String Width
	b_buttons[7].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[7].txtcolor=WHITE; //Set foreground color
	b_buttons[7].bgcolor=HEX(0x54FF45); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[7].font=BigFont; //Select Font
	b_buttons[7].text="Ok"; //Set Text (For formatted strings take sprintf)
	b_buttons[7].callback=b_alarm_ok_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[7]); //Register Button (and run the callback from now on)
	
	//b_alarm_cancel
	b_buttons[8].base.x1=210; //Start X of Button
	b_buttons[8].base.y1=DHEIGHT - 30; //Start Y of Button
	b_buttons[8].base.x2=b_buttons[8].base.x1+160; //Auto Calculate X2 with String Width
	b_buttons[8].base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_buttons[8].txtcolor=WHITE; //Set foreground color
	b_buttons[8].bgcolor=HEX(0xC2C2C2); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_buttons[8].font=BigFont; //Select Font
	b_buttons[8].text="Abbrechen"; //Set Text (For formatted strings take sprintf)
	b_buttons[8].callback=b_alarm_cancel_cb; //Call b1_cb as Callback
	guiAddButton(&b_buttons[8]); //Register Button (and run the callback from now on)
}

ALARM_STRUCT alarm1  = {
.name = "Schule BMS",
.hour=07,
.min=30,
.flags = ALARM_ENABLE | ALARM_MO | ALARM_FR
};

ALARM_STRUCT*  alarms[NUM_ALARMS] ={&alarm1,NULL};
TOUCH_AREA_STRUCT alarms_touchareas[NUM_ALARMS];
BUTTON_STRUCT b_mainmenu;	





void uiAlarmShowAllHide()
{
	for(unsigned char j=0; j<NUM_ALARMS; j++)
	{
		if(alarms[j]!=NULL) 
			touchUnregisterArea(&alarms_touchareas[j]);
	}
	guiRemoveButton(&b_mainmenu);
}
static void b_mainmenu_cb(void* button)
{
	uiAlarmShowAllHide();
	Mainmenu_Show();
}
static void alarms_touchareas_cb(void* touchArea, TOUCH_ACTION triggeredAction)
{
	for(unsigned char i=0; i<NUM_ALARMS; i++)
	{
		if(&alarms_touchareas[i]==(TOUCH_AREA_STRUCT*)touchArea)
		{
			uiAlarmShowAllHide();
			uiAlarmShow(alarms[i]);
			break;
		}
	}
}

void uiAlarmShowAll()
{
	Statusbar_SetTitle("Alle Wecker");
	tftFillRectangle(0,32,DWIDTH,DHEIGHT,HEX(0x65EAFF)); //draw BG
	unsigned char alarm_cnt=0;
	for(unsigned char i=0; i<NUM_ALARMS; i++)
	{
		if(alarms[i]!=NULL)
		{
			if(alarms[i]->flags&ALARM_ENABLE)
				tftDrawLinearGradient(0,32+alarm_cnt*40,WIDTH,40,C_BG_ACTIVE_TOP,C_BG_ACTIVE_BOT,TOP_BOTTOM);
			else
				tftDrawLinearGradient(0,32+alarm_cnt*40,WIDTH,40,C_BG_INACTIVE_TOP,C_BG_INACTIVE_BOT,TOP_BOTTOM);
			tftPrint(10,32+alarm_cnt*40+12,BLACK,TRANSPARENT,BigFont,alarms[i]->name);
			alarms_touchareas[i].x1 = 0;
			alarms_touchareas[i].y1= 32+alarm_cnt*40;
			alarms_touchareas[i].x2=DWIDTH;
			alarms_touchareas[i].y2=32+alarm_cnt*40+39;
			alarms_touchareas[i].hookedActions=PEN_DOWN;
			alarms_touchareas[i].callback = alarms_touchareas_cb;
			touchRegisterArea(&alarms_touchareas[i]);
			alarm_cnt++;
		}
	}
		
	b_mainmenu.base.x1=25; //Start X of Button
	b_mainmenu.base.y1=DHEIGHT - 30; //Start Y of Button
	b_mainmenu.base.x2=b_mainmenu.base.x1+160; //Auto Calculate X2 with String Width
	b_mainmenu.base.y2=AUTO; //Auto Calculate Y2 with String Height
	b_mainmenu.txtcolor=WHITE; //Set foreground color
	b_mainmenu.bgcolor=HEX(0x54FF45); //Set background color (Don't take 255 or 0 on at least one channel, to make shadows possible)
	b_mainmenu.font=BigFont; //Select Font
	b_mainmenu.text="Hauptmen�"; //Set Text (For formatted strings take sprintf)
	b_mainmenu.callback=b_mainmenu_cb; //Call b1_cb as Callback
	guiAddButton(&b_mainmenu); //Register Button (and run the callback from now on)
}