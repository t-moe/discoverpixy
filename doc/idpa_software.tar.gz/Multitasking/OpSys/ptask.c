#include <stdarg.h>
#include "../types.h"
#include "ptask.h"
#include "protect.h"

#define NUM_TASKS 10
PTASK_STRUCT tasks[NUM_TASKS];

void PTask_Init()
{
	for(UCHAR i=0; i<NUM_TASKS; i++)
	{
		tasks[i].events=NULL;
	}
}
PTASK_STRUCT * PTask_AddTask(PTASK_FUNCTION pfCb_, UCHAR ucPriority_,UCHAR ucEventSize_,UCHAR* events_)
{
	if(pfCb_==NULL || events_==NULL)
		return NULL;
	for(UCHAR i=0; i<NUM_TASKS; i++)
	{
		if(tasks[i].events==NULL)	
		{
			tasks[i].ucPriority= ucPriority_;
			tasks[i].pfHandler = pfCb_;
			tasks[i].ucHead=0;
			tasks[i].ucTail=0;
			tasks[i].eventSize=ucEventSize_;
			tasks[i].events = events_;
			return &tasks[i];			
		}	
	}
	return NULL;
}
void PTask_Run_Now(PTASK_STRUCT *pstTask_)
{
	pstTask_->pfHandler(pstTask_,0);
}

BOOL PTask_Loop()
{
	UCHAR i;
	UCHAR ucMaxPri;
	BOOL bExecute;
	BOOL bActive=FALSE;

    bExecute = TRUE;
	while (bExecute == TRUE)
	{
		ucMaxPri = 0;
		bExecute = FALSE;

		// Loop 1 - find the priority to execute
		for (i = 0; i <NUM_TASKS; i++)
		{
			if (tasks[i].events != NULL)
			{
				if (tasks[i].ucPriority > ucMaxPri && tasks[i].ucTail!=tasks[i].ucHead)
    				ucMaxPri = tasks[i].ucPriority;
			}
		}
		// Loop 2 - execute all events for tasks at this priority
		for (i = 0; i <NUM_TASKS; i++)
		{
			if (tasks[i].events != NULL)
			{
				// Is it the right priority?
				if (tasks[i].ucPriority == ucMaxPri)
				{
					while (tasks[i].ucTail!=tasks[i].ucHead)
					{
						bActive=TRUE;
						tasks[i].pfHandler(&tasks[i],tasks[i].events[tasks[i].ucHead]);
						CS_ENTER();
						if (tasks[i].eventSize == 1)
							tasks[i].ucTail=0;	
						else if(tasks[i].events[tasks[i].ucHead]==0x00)
						{
							UCHAR ucNextHead = tasks[i].ucHead + 1 ;
							if (ucNextHead >= tasks[i].eventSize)
								ucNextHead = 0;
							tasks[i].ucHead = ucNextHead;
						}
						CS_EXIT();
						bExecute = TRUE;
					}
				}
			}
		}
	}
	return bActive;// No events found the last time through the list, we're done for now.
}
BOOL PTask_ReadEvent(PTASK_STRUCT *pstTask_,UCHAR* dataloc)
{
	CS_ENTER();
	if(pstTask_->ucTail!=pstTask_->ucHead)
	{
		UCHAR len = pstTask_->events[pstTask_->ucHead];
		UCHAR ucNextHead = pstTask_->ucHead + 1 ;
		if (ucNextHead >= pstTask_->eventSize)
			ucNextHead = 0;
		pstTask_->ucHead = ucNextHead;
		if(pstTask_->ucTail!=pstTask_->ucHead)
		{
			for(UCHAR i=0; i<len; i++)
			{
				*dataloc = pstTask_->events[pstTask_->ucHead];
				dataloc++;
				ucNextHead = pstTask_->ucHead + 1 ;
				if (ucNextHead >= pstTask_->eventSize)
					ucNextHead = 0;
				pstTask_->ucHead = ucNextHead;
			}	
			CS_EXIT();
			return TRUE;	
		}
	}	
	CS_EXIT();
	return FALSE;
}
BOOL PTask_QueueEvent(PTASK_STRUCT *pstTask_, UCHAR length,...)
{
	CS_ENTER();
	if(length>0)
	{
		if( pstTask_->eventSize <3 )
		{
			 CS_EXIT();	
			 return FALSE;
		} 
		unsigned char placeleft;
		if(pstTask_->ucTail>=pstTask_->ucHead)
			placeleft = pstTask_->eventSize - pstTask_->ucTail -1 + pstTask_->ucHead ;
		else
			placeleft = pstTask_->ucHead - pstTask_->ucTail	-1 ;	
		if((length+1)<=placeleft)
		{
			UCHAR ucNextTail= pstTask_->ucTail + 1;
			if (ucNextTail== pstTask_->eventSize)
				ucNextTail = 0;
			pstTask_->events[pstTask_->ucTail]=length;
			pstTask_->ucTail = ucNextTail;
			va_list args;
			va_start (args, length);
			for(UCHAR i=0; i<length; i++)
			{
				ucNextTail= pstTask_->ucTail + 1;
				if (ucNextTail== pstTask_->eventSize)
					ucNextTail = 0;
				// We have a free spot - return TRUE
				pstTask_->events[pstTask_->ucTail] = (unsigned char)va_arg(args,unsigned int);
				pstTask_->ucTail = ucNextTail;
			}				
			va_end (args);
			CS_EXIT();
			return TRUE;
		}
	}
	else
	{
		if(pstTask_->eventSize==1)
		{
			if(pstTask_->ucTail==0)	
			{
				pstTask_->events[0]=0x00;
				pstTask_->ucTail=1;	
				CS_EXIT();	
				return TRUE;		
			}
		}
		else
		{
			// What's the next tail index?
			UCHAR ucNextTail= pstTask_->ucTail + 1;
			if (ucNextTail== pstTask_->eventSize)
				ucNextTail = 0;
			if (ucNextTail != pstTask_->ucHead)
			{
				// We have a free spot - return TRUE
				pstTask_->events[pstTask_->ucTail] = 0x00;
				pstTask_->ucTail = ucNextTail;
				CS_EXIT();
				return TRUE;
			}
		}
	}
	CS_EXIT();
	return FALSE;
}

/*
BOOL PTask_QueueEvent(PTASK_STRUCT *pstTask_, USHORT usEventID_, USHORT usEventData_)
{
	UCHAR ucNextTail;
	BOOL bReturn = FALSE;
	// Protected block
	CS_ENTER();

	// If there's only one element in the queue
	if (pstTask_->pstEvents->ucNumEvents == 1)
	{
		
		if(pstTask_->pstEvents->ucTail==1)
		{
			bReturn = FALSE;
		}			
		else
		{	
			pstTask_->pstEvents->pusEventID[0] = usEventID_;
			pstTask_->pstEvents->pusEventData[0] = usEventData_;
			pstTask_->pstEvents->ucHead = 0;
			pstTask_->pstEvents->ucTail = 1;
			bReturn = TRUE;
		}

	}
	else
	{
		// What's the next tail index?
		ucNextTail= pstTask_->pstEvents->ucTail + 1;
		if (ucNextTail== pstTask_->pstEvents->ucNumEvents)
		{
			ucNextTail = 0;
		}
		
		// If the next tail index is the head index, we're full, so bail
		if (ucNextTail == pstTask_->pstEvents->ucHead)
		{
			bReturn = FALSE;
		}
		else
		{
			// We have a free spot - return TRUE
			pstTask_->pstEvents->pusEventID[pstTask_->pstEvents->ucTail] = usEventID_;
			pstTask_->pstEvents->pusEventData[pstTask_->pstEvents->ucTail] = usEventData_;
			pstTask_->pstEvents->ucTail = ucNextTail;
			bReturn = TRUE;
		}
	}

	//Protected block
	CS_EXIT();

	return bReturn;
}*/


//---------------------------------------------------------------------------
/*!
	Checks to see if there are events in a given task's event queue.
	\fn BOOL PTask_ReadEvent(PTASK_STRUCT *pstTask_, USHORT *pusEventID_, USHORT *pusEventData_)
	\param pstTask_ - pointer to the task
	\param pusEventID_ - array of event IDs
	\param pusEventData_ - array of event Data
	\return TRUE if an event was read, FALSE on queue empty
*/
//---------------------------------------------------------------------------
/*
BOOL PTask_ReadEvent(PTASK_STRUCT *pstTask_, USHORT *pusEventID_, USHORT *pusEventData_)
{
	UCHAR ucNextHead;
	BOOL bFound = FALSE;
	
	// Protection block (events can be written from interrupt context)
	CS_ENTER();

	// If there's only one event
	if (pstTask_->pstEvents->ucNumEvents == 1)
	{
		// And the tail is non-zero, that means we have something...
		if (pstTask_->pstEvents->ucTail == 1)
		{
			// Copy out the event ID and Data
			*pusEventID_ = pstTask_->pstEvents->pusEventID[pstTask_->pstEvents->ucHead];
			*pusEventData_ = pstTask_->pstEvents->pusEventData[pstTask_->pstEvents->ucHead];
			bFound = TRUE;
			pstTask_->pstEvents->ucTail = 0;
		}
	}
	else
	{
		// If the head and tail are not equal, there is pending data
		if (pstTask_->pstEvents->ucHead != pstTask_->pstEvents->ucTail)
		{
			// Copy out the event ID and Data
			*pusEventID_ = pstTask_->pstEvents->pusEventID[pstTask_->pstEvents->ucHead];
			*pusEventData_ = pstTask_->pstEvents->pusEventData[pstTask_->pstEvents->ucHead];
			bFound = TRUE;
			// Set the new tail of the linked list.
			ucNextHead = pstTask_->pstEvents->ucHead + 1 ;
			if (ucNextHead >= pstTask_->pstEvents->ucNumEvents)
			{
				ucNextHead = 0;
			}
			pstTask_->pstEvents->ucHead = ucNextHead;
		}


	}

	// Protection block
	CS_EXIT();

	return bFound;
}

*/