//---------------------------------------------------------------------------
// FunkOS - Copyright (c) 2009, Funkenstein Software, See license.txt for details
//---------------------------------------------------------------------------
/*!
	\file protect.h

	Description:
		Implements critical sections for the specific architecture
*/
//---------------------------------------------------------------------------
#ifndef __PROTECT_H_
#define __PROTECT_H_

//---------------------------------------------------------------------------
#include <avr/interrupt.h>
//---------------------------------------------------------------------------
//!< Define macros for critical section entry/exit (platform specific)
//------------------------------------------------------------------------
//! These macros *must* be used in pairs !
//------------------------------------------------------------------------
//! Enter critical section (copy status register, disable interrupts)
#define CS_ENTER() cli()
//------------------------------------------------------------------------
//! Exit critical section (restore status register)
#define CS_EXIT() sei()

#endif
