//---------------------------------------------------------------------------
// FunkOS - Copyright (c) 2009, Funkenstein Software, See license.txt for details
//---------------------------------------------------------------------------
/*!
	\file:  ptask.h
	
	Description:
		Cooperative mode header files.
*/
//--------------------------------------------------------------------------- 

#ifndef __PTASK_H__
#define __PTASK_H__


// Pseudotask module for cooperative tasks
typedef void (*PTASK_FUNCTION)(void *task, UCHAR length);	//!< Function pointer used...


//---------------------------------------------------------------------------
typedef struct 
{
	UCHAR*				events;          //(top because is acessed very often)
	UCHAR 				ucPriority;		//!< Priority of the ptask
	PTASK_FUNCTION 		pfHandler;		//!< Pointer to the task function
	UCHAR				eventSize;
	UCHAR				ucHead;						//!< Head index in the event buffer (circular)
	UCHAR				ucTail;						//!< Tail index of the event buffer (circular)
} PTASK_STRUCT;

void PTask_Init();

// Initialize an individual ptask
PTASK_STRUCT * PTask_AddTask(PTASK_FUNCTION pfCb_, UCHAR ucPriority_,UCHAR ucEventSize_,UCHAR* events_);


// Function that executes the tasks based on the presence of events in the loop
BOOL PTask_Loop();

void PTask_Run_Now(PTASK_STRUCT *pstTask_);

//---------------------------------------------------------------------------
// Queue event data
BOOL PTask_QueueEvent(PTASK_STRUCT *pstTask_, UCHAR length,...);
BOOL PTask_ReadEvent(PTASK_STRUCT *pstTask_,UCHAR* dataloc);

#endif
